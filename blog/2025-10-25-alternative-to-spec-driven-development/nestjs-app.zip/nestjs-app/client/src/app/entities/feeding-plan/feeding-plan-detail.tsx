import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import {} from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './feeding-plan.reducer';

export const FeedingPlanDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const feedingPlanEntity = useAppSelector(state => state.feedingPlan.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="feedingPlanDetailsHeading">Feeding Plan</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{feedingPlanEntity.id}</dd>
          <dt>
            <span id="diet">Diet</span>
          </dt>
          <dd>{feedingPlanEntity.diet}</dd>
          <dt>
            <span id="foodBrand">Food Brand</span>
          </dt>
          <dd>{feedingPlanEntity.foodBrand}</dd>
          <dt>
            <span id="amountGrams">Amount Grams</span>
          </dt>
          <dd>{feedingPlanEntity.amountGrams}</dd>
          <dt>
            <span id="frequencyPerDay">Frequency Per Day</span>
          </dt>
          <dd>{feedingPlanEntity.frequencyPerDay}</dd>
          <dt>
            <span id="specialInstructions">Special Instructions</span>
          </dt>
          <dd>{feedingPlanEntity.specialInstructions}</dd>
          <dt>Pet</dt>
          <dd>{feedingPlanEntity.pet ? feedingPlanEntity.pet.name : ''}</dd>
        </dl>
        <Button tag={Link} to="/feeding-plan" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/feeding-plan/${feedingPlanEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default FeedingPlanDetail;
