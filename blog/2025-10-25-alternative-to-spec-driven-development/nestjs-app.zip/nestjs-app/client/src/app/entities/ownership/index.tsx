import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import Ownership from './ownership';
import OwnershipDetail from './ownership-detail';
import OwnershipUpdate from './ownership-update';
import OwnershipDeleteDialog from './ownership-delete-dialog';

const OwnershipRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<Ownership />} />
    <Route path="new" element={<OwnershipUpdate />} />
    <Route path=":id">
      <Route index element={<OwnershipDetail />} />
      <Route path="edit" element={<OwnershipUpdate />} />
      <Route path="delete" element={<OwnershipDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default OwnershipRoutes;
