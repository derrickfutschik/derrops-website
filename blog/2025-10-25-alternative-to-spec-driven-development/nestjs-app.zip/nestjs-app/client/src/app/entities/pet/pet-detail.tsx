import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_LOCAL_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './pet.reducer';

export const PetDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const petEntity = useAppSelector(state => state.pet.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="petDetailsHeading">Pet</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{petEntity.id}</dd>
          <dt>
            <span id="name">Name</span>
          </dt>
          <dd>{petEntity.name}</dd>
          <dt>
            <span id="species">Species</span>
          </dt>
          <dd>{petEntity.species}</dd>
          <dt>
            <span id="sex">Sex</span>
          </dt>
          <dd>{petEntity.sex}</dd>
          <dt>
            <span id="dateOfBirth">Date Of Birth</span>
          </dt>
          <dd>{petEntity.dateOfBirth ? <TextFormat value={petEntity.dateOfBirth} type="date" format={APP_LOCAL_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="estimatedAgeMonths">Estimated Age Months</span>
          </dt>
          <dd>{petEntity.estimatedAgeMonths}</dd>
          <dt>
            <span id="color">Color</span>
          </dt>
          <dd>{petEntity.color}</dd>
          <dt>
            <span id="microchipNumber">Microchip Number</span>
          </dt>
          <dd>{petEntity.microchipNumber}</dd>
          <dt>
            <span id="intakeDate">Intake Date</span>
          </dt>
          <dd>{petEntity.intakeDate ? <TextFormat value={petEntity.intakeDate} type="date" format={APP_LOCAL_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="status">Status</span>
          </dt>
          <dd>{petEntity.status}</dd>
          <dt>
            <span id="neutered">Neutered</span>
          </dt>
          <dd>{petEntity.neutered ? 'true' : 'false'}</dd>
          <dt>
            <span id="weightKg">Weight Kg</span>
          </dt>
          <dd>{petEntity.weightKg}</dd>
          <dt>
            <span id="temperament">Temperament</span>
          </dt>
          <dd>{petEntity.temperament}</dd>
          <dt>
            <span id="description">Description</span>
          </dt>
          <dd>{petEntity.description}</dd>
          <dt>Breed</dt>
          <dd>{petEntity.breed ? petEntity.breed.name : ''}</dd>
          <dt>Enclosure</dt>
          <dd>{petEntity.enclosure ? petEntity.enclosure.code : ''}</dd>
        </dl>
        <Button tag={Link} to="/pet" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/pet/${petEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default PetDetail;
