import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm, isNumber } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { EnclosureType } from 'app/shared/model/enumerations/enclosure-type.model';
import { createEntity, getEntity, reset, updateEntity } from './enclosure.reducer';

export const EnclosureUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const enclosureEntity = useAppSelector(state => state.enclosure.entity);
  const loading = useAppSelector(state => state.enclosure.loading);
  const updating = useAppSelector(state => state.enclosure.updating);
  const updateSuccess = useAppSelector(state => state.enclosure.updateSuccess);
  const enclosureTypeValues = Object.keys(EnclosureType);

  const handleClose = () => {
    navigate('/enclosure');
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    if (values.capacity !== undefined && typeof values.capacity !== 'number') {
      values.capacity = Number(values.capacity);
    }

    const entity = {
      ...enclosureEntity,
      ...values,
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          type: 'KENNEL',
          ...enclosureEntity,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.enclosure.home.createOrEditLabel" data-cy="EnclosureCreateUpdateHeading">
            Create or edit a Enclosure
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="enclosure-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField
                label="Code"
                id="enclosure-code"
                name="code"
                data-cy="code"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                  minLength: { value: 1, message: 'This field is required to be at least 1 characters.' },
                  maxLength: { value: 30, message: 'This field cannot be longer than 30 characters.' },
                }}
              />
              <ValidatedField label="Type" id="enclosure-type" name="type" data-cy="type" type="select">
                {enclosureTypeValues.map(enclosureType => (
                  <option value={enclosureType} key={enclosureType}>
                    {enclosureType}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Capacity"
                id="enclosure-capacity"
                name="capacity"
                data-cy="capacity"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                  min: { value: 1, message: 'This field should be at least 1.' },
                  max: { value: 50, message: 'This field cannot be more than 50.' },
                  validate: v => isNumber(v) || 'This field should be a number.',
                }}
              />
              <ValidatedField
                label="Location"
                id="enclosure-location"
                name="location"
                data-cy="location"
                type="text"
                validate={{
                  maxLength: { value: 120, message: 'This field cannot be longer than 120 characters.' },
                }}
              />
              <ValidatedField
                label="Notes"
                id="enclosure-notes"
                name="notes"
                data-cy="notes"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/enclosure" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default EnclosureUpdate;
