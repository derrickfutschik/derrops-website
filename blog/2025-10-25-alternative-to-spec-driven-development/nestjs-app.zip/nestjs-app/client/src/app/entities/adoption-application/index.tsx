import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import AdoptionApplication from './adoption-application';
import AdoptionApplicationDetail from './adoption-application-detail';
import AdoptionApplicationUpdate from './adoption-application-update';
import AdoptionApplicationDeleteDialog from './adoption-application-delete-dialog';

const AdoptionApplicationRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<AdoptionApplication />} />
    <Route path="new" element={<AdoptionApplicationUpdate />} />
    <Route path=":id">
      <Route index element={<AdoptionApplicationDetail />} />
      <Route path="edit" element={<AdoptionApplicationUpdate />} />
      <Route path="delete" element={<AdoptionApplicationDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default AdoptionApplicationRoutes;
