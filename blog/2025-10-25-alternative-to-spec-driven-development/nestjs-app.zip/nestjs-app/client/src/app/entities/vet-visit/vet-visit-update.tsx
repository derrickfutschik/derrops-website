import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { createEntity, getEntity, reset, updateEntity } from './vet-visit.reducer';

export const VetVisitUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const vetVisitEntity = useAppSelector(state => state.vetVisit.entity);
  const loading = useAppSelector(state => state.vetVisit.loading);
  const updating = useAppSelector(state => state.vetVisit.updating);
  const updateSuccess = useAppSelector(state => state.vetVisit.updateSuccess);

  const handleClose = () => {
    navigate(`/vet-visit${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.visitDate = convertDateTimeToServer(values.visitDate);

    const entity = {
      ...vetVisitEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          visitDate: displayDefaultDateTime(),
        }
      : {
          ...vetVisitEntity,
          visitDate: convertDateTimeFromServer(vetVisitEntity.visitDate),
          pet: vetVisitEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.vetVisit.home.createOrEditLabel" data-cy="VetVisitCreateUpdateHeading">
            Create or edit a Vet Visit
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="vet-visit-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField
                label="Visit Date"
                id="vet-visit-visitDate"
                name="visitDate"
                data-cy="visitDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Clinic Name"
                id="vet-visit-clinicName"
                name="clinicName"
                data-cy="clinicName"
                type="text"
                validate={{
                  maxLength: { value: 120, message: 'This field cannot be longer than 120 characters.' },
                }}
              />
              <ValidatedField
                label="Vet Name"
                id="vet-visit-vetName"
                name="vetName"
                data-cy="vetName"
                type="text"
                validate={{
                  maxLength: { value: 80, message: 'This field cannot be longer than 80 characters.' },
                }}
              />
              <ValidatedField
                label="Reason"
                id="vet-visit-reason"
                name="reason"
                data-cy="reason"
                type="text"
                validate={{
                  maxLength: { value: 160, message: 'This field cannot be longer than 160 characters.' },
                }}
              />
              <ValidatedField
                label="Report"
                id="vet-visit-report"
                name="report"
                data-cy="report"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="vet-visit-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/vet-visit" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default VetVisitUpdate;
