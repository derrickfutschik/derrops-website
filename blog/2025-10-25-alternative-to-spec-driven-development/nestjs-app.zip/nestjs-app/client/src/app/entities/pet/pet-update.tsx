import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm, isNumber } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getBreeds } from 'app/entities/breed/breed.reducer';
import { getEntities as getEnclosures } from 'app/entities/enclosure/enclosure.reducer';
import { SpeciesType } from 'app/shared/model/enumerations/species-type.model';
import { Sex } from 'app/shared/model/enumerations/sex.model';
import { PetStatus } from 'app/shared/model/enumerations/pet-status.model';
import { Temperament } from 'app/shared/model/enumerations/temperament.model';
import { createEntity, getEntity, reset, updateEntity } from './pet.reducer';

export const PetUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const breeds = useAppSelector(state => state.breed.entities);
  const enclosures = useAppSelector(state => state.enclosure.entities);
  const petEntity = useAppSelector(state => state.pet.entity);
  const loading = useAppSelector(state => state.pet.loading);
  const updating = useAppSelector(state => state.pet.updating);
  const updateSuccess = useAppSelector(state => state.pet.updateSuccess);
  const speciesTypeValues = Object.keys(SpeciesType);
  const sexValues = Object.keys(Sex);
  const petStatusValues = Object.keys(PetStatus);
  const temperamentValues = Object.keys(Temperament);

  const handleClose = () => {
    navigate(`/pet${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getBreeds({}));
    dispatch(getEnclosures({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    if (values.estimatedAgeMonths !== undefined && typeof values.estimatedAgeMonths !== 'number') {
      values.estimatedAgeMonths = Number(values.estimatedAgeMonths);
    }
    if (values.weightKg !== undefined && typeof values.weightKg !== 'number') {
      values.weightKg = Number(values.weightKg);
    }

    const entity = {
      ...petEntity,
      ...values,
      breed: breeds.find(it => it.id.toString() === values.breed?.toString()),
      enclosure: enclosures.find(it => it.id.toString() === values.enclosure?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          species: 'DOG',
          sex: 'MALE',
          status: 'INTAKE',
          temperament: 'CALM',
          ...petEntity,
          breed: petEntity?.breed?.id,
          enclosure: petEntity?.enclosure?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.pet.home.createOrEditLabel" data-cy="PetCreateUpdateHeading">
            Create or edit a Pet
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="pet-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField
                label="Name"
                id="pet-name"
                name="name"
                data-cy="name"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                  minLength: { value: 1, message: 'This field is required to be at least 1 characters.' },
                  maxLength: { value: 60, message: 'This field cannot be longer than 60 characters.' },
                }}
              />
              <ValidatedField label="Species" id="pet-species" name="species" data-cy="species" type="select">
                {speciesTypeValues.map(speciesType => (
                  <option value={speciesType} key={speciesType}>
                    {speciesType}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField label="Sex" id="pet-sex" name="sex" data-cy="sex" type="select">
                {sexValues.map(sex => (
                  <option value={sex} key={sex}>
                    {sex}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField label="Date Of Birth" id="pet-dateOfBirth" name="dateOfBirth" data-cy="dateOfBirth" type="date" />
              <ValidatedField
                label="Estimated Age Months"
                id="pet-estimatedAgeMonths"
                name="estimatedAgeMonths"
                data-cy="estimatedAgeMonths"
                type="text"
                validate={{
                  min: { value: 0, message: 'This field should be at least 0.' },
                  max: { value: 3600, message: 'This field cannot be more than 3600.' },
                  validate: v => isNumber(v) || 'This field should be a number.',
                }}
              />
              <ValidatedField
                label="Color"
                id="pet-color"
                name="color"
                data-cy="color"
                type="text"
                validate={{
                  maxLength: { value: 60, message: 'This field cannot be longer than 60 characters.' },
                }}
              />
              <ValidatedField
                label="Microchip Number"
                id="pet-microchipNumber"
                name="microchipNumber"
                data-cy="microchipNumber"
                type="text"
                validate={{
                  maxLength: { value: 25, message: 'This field cannot be longer than 25 characters.' },
                  pattern: {
                    value: /^[A-Za-z0-9\-]{5,25}$/,
                    message: translate('entity.validation.pattern', { pattern: '^[A-Za-z0-9\\-]{5,25}$' }),
                  },
                }}
              />
              <ValidatedField
                label="Intake Date"
                id="pet-intakeDate"
                name="intakeDate"
                data-cy="intakeDate"
                type="date"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="Status" id="pet-status" name="status" data-cy="status" type="select">
                {petStatusValues.map(petStatus => (
                  <option value={petStatus} key={petStatus}>
                    {petStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField label="Neutered" id="pet-neutered" name="neutered" data-cy="neutered" check type="checkbox" />
              <ValidatedField
                label="Weight Kg"
                id="pet-weightKg"
                name="weightKg"
                data-cy="weightKg"
                type="text"
                validate={{
                  min: { value: 0, message: 'This field should be at least 0.' },
                  max: { value: 200, message: 'This field cannot be more than 200.' },
                  validate: v => isNumber(v) || 'This field should be a number.',
                }}
              />
              <ValidatedField label="Temperament" id="pet-temperament" name="temperament" data-cy="temperament" type="select">
                {temperamentValues.map(temperament => (
                  <option value={temperament} key={temperament}>
                    {temperament}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Description"
                id="pet-description"
                name="description"
                data-cy="description"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="pet-breed" name="breed" data-cy="breed" label="Breed" type="select">
                <option value="" key="0" />
                {breeds
                  ? breeds.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="pet-enclosure" name="enclosure" data-cy="enclosure" label="Enclosure" type="select">
                <option value="" key="0" />
                {enclosures
                  ? enclosures.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.code}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/pet" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default PetUpdate;
