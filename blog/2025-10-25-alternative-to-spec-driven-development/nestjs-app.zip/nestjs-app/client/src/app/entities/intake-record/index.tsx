import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import IntakeRecord from './intake-record';
import IntakeRecordDetail from './intake-record-detail';
import IntakeRecordUpdate from './intake-record-update';
import IntakeRecordDeleteDialog from './intake-record-delete-dialog';

const IntakeRecordRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<IntakeRecord />} />
    <Route path="new" element={<IntakeRecordUpdate />} />
    <Route path=":id">
      <Route index element={<IntakeRecordDetail />} />
      <Route path="edit" element={<IntakeRecordUpdate />} />
      <Route path="delete" element={<IntakeRecordDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default IntakeRecordRoutes;
