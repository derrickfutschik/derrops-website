import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import {} from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './breed.reducer';

export const BreedDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const breedEntity = useAppSelector(state => state.breed.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="breedDetailsHeading">Breed</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{breedEntity.id}</dd>
          <dt>
            <span id="name">Name</span>
          </dt>
          <dd>{breedEntity.name}</dd>
          <dt>
            <span id="species">Species</span>
          </dt>
          <dd>{breedEntity.species}</dd>
          <dt>
            <span id="sizeLabel">Size Label</span>
          </dt>
          <dd>{breedEntity.sizeLabel}</dd>
          <dt>
            <span id="notes">Notes</span>
          </dt>
          <dd>{breedEntity.notes}</dd>
        </dl>
        <Button tag={Link} to="/breed" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/breed/${breedEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default BreedDetail;
