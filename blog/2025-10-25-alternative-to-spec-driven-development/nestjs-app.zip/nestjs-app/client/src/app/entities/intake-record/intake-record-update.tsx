import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, FormText, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { IntakeSource } from 'app/shared/model/enumerations/intake-source.model';
import { createEntity, getEntity, reset, updateEntity } from './intake-record.reducer';

export const IntakeRecordUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const intakeRecordEntity = useAppSelector(state => state.intakeRecord.entity);
  const loading = useAppSelector(state => state.intakeRecord.loading);
  const updating = useAppSelector(state => state.intakeRecord.updating);
  const updateSuccess = useAppSelector(state => state.intakeRecord.updateSuccess);
  const intakeSourceValues = Object.keys(IntakeSource);

  const handleClose = () => {
    navigate('/intake-record');
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...intakeRecordEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          source: 'SURRENDER',
          ...intakeRecordEntity,
          pet: intakeRecordEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.intakeRecord.home.createOrEditLabel" data-cy="IntakeRecordCreateUpdateHeading">
            Create or edit a Intake Record
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="intake-record-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField
                label="Intake Date"
                id="intake-record-intakeDate"
                name="intakeDate"
                data-cy="intakeDate"
                type="date"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="Source" id="intake-record-source" name="source" data-cy="source" type="select">
                {intakeSourceValues.map(intakeSource => (
                  <option value={intakeSource} key={intakeSource}>
                    {intakeSource}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Found Location"
                id="intake-record-foundLocation"
                name="foundLocation"
                data-cy="foundLocation"
                type="text"
                validate={{
                  maxLength: { value: 160, message: 'This field cannot be longer than 160 characters.' },
                }}
              />
              <ValidatedField
                label="Surrendered Reason"
                id="intake-record-surrenderedReason"
                name="surrenderedReason"
                data-cy="surrenderedReason"
                type="text"
                validate={{
                  maxLength: { value: 200, message: 'This field cannot be longer than 200 characters.' },
                }}
              />
              <ValidatedField
                label="Initial Health Notes"
                id="intake-record-initialHealthNotes"
                name="initialHealthNotes"
                data-cy="initialHealthNotes"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="intake-record-pet" name="pet" data-cy="pet" label="Pet" type="select" required>
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <FormText>This field is required.</FormText>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/intake-record" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default IntakeRecordUpdate;
