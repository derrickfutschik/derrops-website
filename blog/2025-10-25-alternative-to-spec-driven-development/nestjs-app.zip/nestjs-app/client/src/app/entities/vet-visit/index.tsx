import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import VetVisit from './vet-visit';
import VetVisitDetail from './vet-visit-detail';
import VetVisitUpdate from './vet-visit-update';
import VetVisitDeleteDialog from './vet-visit-delete-dialog';

const VetVisitRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<VetVisit />} />
    <Route path="new" element={<VetVisitUpdate />} />
    <Route path=":id">
      <Route index element={<VetVisitDetail />} />
      <Route path="edit" element={<VetVisitUpdate />} />
      <Route path="delete" element={<VetVisitDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default VetVisitRoutes;
