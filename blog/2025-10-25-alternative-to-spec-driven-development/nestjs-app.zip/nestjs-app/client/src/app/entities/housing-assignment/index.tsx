import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import HousingAssignment from './housing-assignment';
import HousingAssignmentDetail from './housing-assignment-detail';
import HousingAssignmentUpdate from './housing-assignment-update';
import HousingAssignmentDeleteDialog from './housing-assignment-delete-dialog';

const HousingAssignmentRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<HousingAssignment />} />
    <Route path="new" element={<HousingAssignmentUpdate />} />
    <Route path=":id">
      <Route index element={<HousingAssignmentDetail />} />
      <Route path="edit" element={<HousingAssignmentUpdate />} />
      <Route path="delete" element={<HousingAssignmentDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default HousingAssignmentRoutes;
