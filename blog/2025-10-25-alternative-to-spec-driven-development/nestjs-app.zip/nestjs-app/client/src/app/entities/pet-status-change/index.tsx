import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import PetStatusChange from './pet-status-change';
import PetStatusChangeDetail from './pet-status-change-detail';
import PetStatusChangeUpdate from './pet-status-change-update';
import PetStatusChangeDeleteDialog from './pet-status-change-delete-dialog';

const PetStatusChangeRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<PetStatusChange />} />
    <Route path="new" element={<PetStatusChangeUpdate />} />
    <Route path=":id">
      <Route index element={<PetStatusChangeDetail />} />
      <Route path="edit" element={<PetStatusChangeUpdate />} />
      <Route path="delete" element={<PetStatusChangeDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default PetStatusChangeRoutes;
