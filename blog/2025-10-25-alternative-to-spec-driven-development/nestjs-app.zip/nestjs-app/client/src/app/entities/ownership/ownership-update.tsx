import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPeople } from 'app/entities/person/person.reducer';
import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { OwnershipType } from 'app/shared/model/enumerations/ownership-type.model';
import { createEntity, getEntity, updateEntity } from './ownership.reducer';

export const OwnershipUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const people = useAppSelector(state => state.person.entities);
  const pets = useAppSelector(state => state.pet.entities);
  const ownershipEntity = useAppSelector(state => state.ownership.entity);
  const loading = useAppSelector(state => state.ownership.loading);
  const updating = useAppSelector(state => state.ownership.updating);
  const updateSuccess = useAppSelector(state => state.ownership.updateSuccess);
  const ownershipTypeValues = Object.keys(OwnershipType);

  const handleClose = () => {
    navigate('/ownership');
  };

  useEffect(() => {
    if (!isNew) {
      dispatch(getEntity(id));
    }

    dispatch(getPeople({}));
    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...ownershipEntity,
      ...values,
      owner: people.find(it => it.id.toString() === values.owner?.toString()),
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          type: 'ADOPTION',
          ...ownershipEntity,
          owner: ownershipEntity?.owner?.id,
          pet: ownershipEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.ownership.home.createOrEditLabel" data-cy="OwnershipCreateUpdateHeading">
            Create or edit a Ownership
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="ownership-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField label="Type" id="ownership-type" name="type" data-cy="type" type="select">
                {ownershipTypeValues.map(ownershipType => (
                  <option value={ownershipType} key={ownershipType}>
                    {ownershipType}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Start Date"
                id="ownership-startDate"
                name="startDate"
                data-cy="startDate"
                type="date"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="End Date" id="ownership-endDate" name="endDate" data-cy="endDate" type="date" />
              <ValidatedField id="ownership-owner" name="owner" data-cy="owner" label="Owner" type="select">
                <option value="" key="0" />
                {people
                  ? people.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.lastName}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="ownership-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/ownership" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default OwnershipUpdate;
