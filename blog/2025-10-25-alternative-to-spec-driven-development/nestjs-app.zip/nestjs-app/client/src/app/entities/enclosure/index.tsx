import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import Enclosure from './enclosure';
import EnclosureDetail from './enclosure-detail';
import EnclosureUpdate from './enclosure-update';
import EnclosureDeleteDialog from './enclosure-delete-dialog';

const EnclosureRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<Enclosure />} />
    <Route path="new" element={<EnclosureUpdate />} />
    <Route path=":id">
      <Route index element={<EnclosureDetail />} />
      <Route path="edit" element={<EnclosureUpdate />} />
      <Route path="delete" element={<EnclosureDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default EnclosureRoutes;
