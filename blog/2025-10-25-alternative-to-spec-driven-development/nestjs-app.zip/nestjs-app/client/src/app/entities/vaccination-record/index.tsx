import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import VaccinationRecord from './vaccination-record';
import VaccinationRecordDetail from './vaccination-record-detail';
import VaccinationRecordUpdate from './vaccination-record-update';
import VaccinationRecordDeleteDialog from './vaccination-record-delete-dialog';

const VaccinationRecordRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<VaccinationRecord />} />
    <Route path="new" element={<VaccinationRecordUpdate />} />
    <Route path=":id">
      <Route index element={<VaccinationRecordDetail />} />
      <Route path="edit" element={<VaccinationRecordUpdate />} />
      <Route path="delete" element={<VaccinationRecordDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default VaccinationRecordRoutes;
