import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import {} from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './person.reducer';

export const PersonDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const personEntity = useAppSelector(state => state.person.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="personDetailsHeading">Person</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{personEntity.id}</dd>
          <dt>
            <span id="firstName">First Name</span>
          </dt>
          <dd>{personEntity.firstName}</dd>
          <dt>
            <span id="lastName">Last Name</span>
          </dt>
          <dd>{personEntity.lastName}</dd>
          <dt>
            <span id="phone">Phone</span>
          </dt>
          <dd>{personEntity.phone}</dd>
          <dt>
            <span id="email">Email</span>
          </dt>
          <dd>{personEntity.email}</dd>
          <dt>
            <span id="street">Street</span>
          </dt>
          <dd>{personEntity.street}</dd>
          <dt>
            <span id="city">City</span>
          </dt>
          <dd>{personEntity.city}</dd>
          <dt>
            <span id="state">State</span>
          </dt>
          <dd>{personEntity.state}</dd>
          <dt>
            <span id="postalCode">Postal Code</span>
          </dt>
          <dd>{personEntity.postalCode}</dd>
          <dt>
            <span id="country">Country</span>
          </dt>
          <dd>{personEntity.country}</dd>
          <dt>
            <span id="verified">Verified</span>
          </dt>
          <dd>{personEntity.verified ? 'true' : 'false'}</dd>
        </dl>
        <Button tag={Link} to="/person" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/person/${personEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default PersonDetail;
