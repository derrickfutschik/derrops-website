import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import Breed from './breed';
import Person from './person';
import Enclosure from './enclosure';
import HousingAssignment from './housing-assignment';
import IntakeRecord from './intake-record';
import Pet from './pet';
import PetStatusChange from './pet-status-change';
import VaccinationRecord from './vaccination-record';
import MedicalCondition from './medical-condition';
import VetVisit from './vet-visit';
import Treatment from './treatment';
import FeedingPlan from './feeding-plan';
import Photo from './photo';
import AdoptionApplication from './adoption-application';
import Ownership from './ownership';
/* jhipster-needle-add-route-import - JHipster will add routes here */

export default () => {
  return (
    <div>
      <ErrorBoundaryRoutes>
        {/* prettier-ignore */}
        <Route path="breed/*" element={<Breed />} />
        <Route path="person/*" element={<Person />} />
        <Route path="enclosure/*" element={<Enclosure />} />
        <Route path="housing-assignment/*" element={<HousingAssignment />} />
        <Route path="intake-record/*" element={<IntakeRecord />} />
        <Route path="pet/*" element={<Pet />} />
        <Route path="pet-status-change/*" element={<PetStatusChange />} />
        <Route path="vaccination-record/*" element={<VaccinationRecord />} />
        <Route path="medical-condition/*" element={<MedicalCondition />} />
        <Route path="vet-visit/*" element={<VetVisit />} />
        <Route path="treatment/*" element={<Treatment />} />
        <Route path="feeding-plan/*" element={<FeedingPlan />} />
        <Route path="photo/*" element={<Photo />} />
        <Route path="adoption-application/*" element={<AdoptionApplication />} />
        <Route path="ownership/*" element={<Ownership />} />
        {/* jhipster-needle-add-route-path - JHipster will add routes here */}
      </ErrorBoundaryRoutes>
    </div>
  );
};
