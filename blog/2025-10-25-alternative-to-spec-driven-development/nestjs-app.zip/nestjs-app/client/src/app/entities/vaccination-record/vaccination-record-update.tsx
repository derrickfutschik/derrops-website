import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { Vaccine } from 'app/shared/model/enumerations/vaccine.model';
import { createEntity, getEntity, updateEntity } from './vaccination-record.reducer';

export const VaccinationRecordUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const vaccinationRecordEntity = useAppSelector(state => state.vaccinationRecord.entity);
  const loading = useAppSelector(state => state.vaccinationRecord.loading);
  const updating = useAppSelector(state => state.vaccinationRecord.updating);
  const updateSuccess = useAppSelector(state => state.vaccinationRecord.updateSuccess);
  const vaccineValues = Object.keys(Vaccine);

  const handleClose = () => {
    navigate('/vaccination-record');
  };

  useEffect(() => {
    if (!isNew) {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...vaccinationRecordEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          vaccine: 'RABIES',
          ...vaccinationRecordEntity,
          pet: vaccinationRecordEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.vaccinationRecord.home.createOrEditLabel" data-cy="VaccinationRecordCreateUpdateHeading">
            Create or edit a Vaccination Record
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="vaccination-record-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField label="Vaccine" id="vaccination-record-vaccine" name="vaccine" data-cy="vaccine" type="select">
                {vaccineValues.map(vaccine => (
                  <option value={vaccine} key={vaccine}>
                    {vaccine}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Date Given"
                id="vaccination-record-dateGiven"
                name="dateGiven"
                data-cy="dateGiven"
                type="date"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="Due Date" id="vaccination-record-dueDate" name="dueDate" data-cy="dueDate" type="date" />
              <ValidatedField
                label="Administered By"
                id="vaccination-record-administeredBy"
                name="administeredBy"
                data-cy="administeredBy"
                type="text"
                validate={{
                  maxLength: { value: 80, message: 'This field cannot be longer than 80 characters.' },
                }}
              />
              <ValidatedField
                label="Notes"
                id="vaccination-record-notes"
                name="notes"
                data-cy="notes"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="vaccination-record-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/vaccination-record" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default VaccinationRecordUpdate;
