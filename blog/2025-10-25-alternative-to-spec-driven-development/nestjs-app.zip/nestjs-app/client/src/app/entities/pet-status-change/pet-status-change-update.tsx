import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { PetStatus } from 'app/shared/model/enumerations/pet-status.model';
import { createEntity, getEntity, updateEntity } from './pet-status-change.reducer';

export const PetStatusChangeUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const petStatusChangeEntity = useAppSelector(state => state.petStatusChange.entity);
  const loading = useAppSelector(state => state.petStatusChange.loading);
  const updating = useAppSelector(state => state.petStatusChange.updating);
  const updateSuccess = useAppSelector(state => state.petStatusChange.updateSuccess);
  const petStatusValues = Object.keys(PetStatus);

  const handleClose = () => {
    navigate('/pet-status-change');
  };

  useEffect(() => {
    if (!isNew) {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.changedAt = convertDateTimeToServer(values.changedAt);

    const entity = {
      ...petStatusChangeEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          changedAt: displayDefaultDateTime(),
        }
      : {
          fromStatus: 'INTAKE',
          toStatus: 'INTAKE',
          ...petStatusChangeEntity,
          changedAt: convertDateTimeFromServer(petStatusChangeEntity.changedAt),
          pet: petStatusChangeEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.petStatusChange.home.createOrEditLabel" data-cy="PetStatusChangeCreateUpdateHeading">
            Create or edit a Pet Status Change
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="pet-status-change-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField label="From Status" id="pet-status-change-fromStatus" name="fromStatus" data-cy="fromStatus" type="select">
                {petStatusValues.map(petStatus => (
                  <option value={petStatus} key={petStatus}>
                    {petStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField label="To Status" id="pet-status-change-toStatus" name="toStatus" data-cy="toStatus" type="select">
                {petStatusValues.map(petStatus => (
                  <option value={petStatus} key={petStatus}>
                    {petStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Changed At"
                id="pet-status-change-changedAt"
                name="changedAt"
                data-cy="changedAt"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField
                label="Reason"
                id="pet-status-change-reason"
                name="reason"
                data-cy="reason"
                type="text"
                validate={{
                  maxLength: { value: 200, message: 'This field cannot be longer than 200 characters.' },
                }}
              />
              <ValidatedField id="pet-status-change-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/pet-status-change" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default PetStatusChangeUpdate;
