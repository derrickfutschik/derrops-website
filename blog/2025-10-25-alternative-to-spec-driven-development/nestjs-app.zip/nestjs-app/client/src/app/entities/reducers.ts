import breed from 'app/entities/breed/breed.reducer';
import person from 'app/entities/person/person.reducer';
import enclosure from 'app/entities/enclosure/enclosure.reducer';
import housingAssignment from 'app/entities/housing-assignment/housing-assignment.reducer';
import intakeRecord from 'app/entities/intake-record/intake-record.reducer';
import pet from 'app/entities/pet/pet.reducer';
import petStatusChange from 'app/entities/pet-status-change/pet-status-change.reducer';
import vaccinationRecord from 'app/entities/vaccination-record/vaccination-record.reducer';
import medicalCondition from 'app/entities/medical-condition/medical-condition.reducer';
import vetVisit from 'app/entities/vet-visit/vet-visit.reducer';
import treatment from 'app/entities/treatment/treatment.reducer';
import feedingPlan from 'app/entities/feeding-plan/feeding-plan.reducer';
import photo from 'app/entities/photo/photo.reducer';
import adoptionApplication from 'app/entities/adoption-application/adoption-application.reducer';
import ownership from 'app/entities/ownership/ownership.reducer';
/* jhipster-needle-add-reducer-import - JHipster will add reducer here */

const entitiesReducers = {
  breed,
  person,
  enclosure,
  housingAssignment,
  intakeRecord,
  pet,
  petStatusChange,
  vaccinationRecord,
  medicalCondition,
  vetVisit,
  treatment,
  feedingPlan,
  photo,
  adoptionApplication,
  ownership,
  /* jhipster-needle-add-reducer-combine - JHipster will add reducer here */
};

export default entitiesReducers;
