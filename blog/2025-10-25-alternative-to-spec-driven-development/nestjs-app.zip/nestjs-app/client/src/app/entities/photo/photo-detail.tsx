import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat, byteSize, openFile } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './photo.reducer';

export const PhotoDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const photoEntity = useAppSelector(state => state.photo.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="photoDetailsHeading">Photo</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{photoEntity.id}</dd>
          <dt>
            <span id="imageData">Image Data</span>
          </dt>
          <dd>
            {photoEntity.imageData ? (
              <div>
                {photoEntity.imageDataContentType ? (
                  <a onClick={openFile(photoEntity.imageDataContentType, photoEntity.imageData)}>Open&nbsp;</a>
                ) : null}
                <span>
                  {photoEntity.imageDataContentType}, {byteSize(photoEntity.imageData)}
                </span>
              </div>
            ) : null}
          </dd>
          <dt>
            <span id="caption">Caption</span>
          </dt>
          <dd>{photoEntity.caption}</dd>
          <dt>
            <span id="takenAt">Taken At</span>
          </dt>
          <dd>{photoEntity.takenAt ? <TextFormat value={photoEntity.takenAt} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>Pet</dt>
          <dd>{photoEntity.pet ? photoEntity.pet.name : ''}</dd>
        </dl>
        <Button tag={Link} to="/photo" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/photo/${photoEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default PhotoDetail;
