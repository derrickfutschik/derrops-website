import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import MedicalCondition from './medical-condition';
import MedicalConditionDetail from './medical-condition-detail';
import MedicalConditionUpdate from './medical-condition-update';
import MedicalConditionDeleteDialog from './medical-condition-delete-dialog';

const MedicalConditionRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<MedicalCondition />} />
    <Route path="new" element={<MedicalConditionUpdate />} />
    <Route path=":id">
      <Route index element={<MedicalConditionDetail />} />
      <Route path="edit" element={<MedicalConditionUpdate />} />
      <Route path="delete" element={<MedicalConditionDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default MedicalConditionRoutes;
