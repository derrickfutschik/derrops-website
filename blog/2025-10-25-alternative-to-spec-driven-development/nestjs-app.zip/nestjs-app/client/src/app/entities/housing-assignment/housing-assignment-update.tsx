import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { getEntities as getEnclosures } from 'app/entities/enclosure/enclosure.reducer';
import { createEntity, getEntity, updateEntity } from './housing-assignment.reducer';

export const HousingAssignmentUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const enclosures = useAppSelector(state => state.enclosure.entities);
  const housingAssignmentEntity = useAppSelector(state => state.housingAssignment.entity);
  const loading = useAppSelector(state => state.housingAssignment.loading);
  const updating = useAppSelector(state => state.housingAssignment.updating);
  const updateSuccess = useAppSelector(state => state.housingAssignment.updateSuccess);

  const handleClose = () => {
    navigate('/housing-assignment');
  };

  useEffect(() => {
    if (!isNew) {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
    dispatch(getEnclosures({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...housingAssignmentEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
      enclosure: enclosures.find(it => it.id.toString() === values.enclosure?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          ...housingAssignmentEntity,
          pet: housingAssignmentEntity?.pet?.id,
          enclosure: housingAssignmentEntity?.enclosure?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.housingAssignment.home.createOrEditLabel" data-cy="HousingAssignmentCreateUpdateHeading">
            Create or edit a Housing Assignment
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="housing-assignment-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField
                label="Start Date"
                id="housing-assignment-startDate"
                name="startDate"
                data-cy="startDate"
                type="date"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="End Date" id="housing-assignment-endDate" name="endDate" data-cy="endDate" type="date" />
              <ValidatedField id="housing-assignment-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="housing-assignment-enclosure" name="enclosure" data-cy="enclosure" label="Enclosure" type="select">
                <option value="" key="0" />
                {enclosures
                  ? enclosures.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.code}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/housing-assignment" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default HousingAssignmentUpdate;
