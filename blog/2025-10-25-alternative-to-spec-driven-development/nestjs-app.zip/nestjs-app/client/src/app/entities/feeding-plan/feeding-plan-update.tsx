import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm, isNumber } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { DietType } from 'app/shared/model/enumerations/diet-type.model';
import { createEntity, getEntity, reset, updateEntity } from './feeding-plan.reducer';

export const FeedingPlanUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const feedingPlanEntity = useAppSelector(state => state.feedingPlan.entity);
  const loading = useAppSelector(state => state.feedingPlan.loading);
  const updating = useAppSelector(state => state.feedingPlan.updating);
  const updateSuccess = useAppSelector(state => state.feedingPlan.updateSuccess);
  const dietTypeValues = Object.keys(DietType);

  const handleClose = () => {
    navigate('/feeding-plan');
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    if (values.amountGrams !== undefined && typeof values.amountGrams !== 'number') {
      values.amountGrams = Number(values.amountGrams);
    }
    if (values.frequencyPerDay !== undefined && typeof values.frequencyPerDay !== 'number') {
      values.frequencyPerDay = Number(values.frequencyPerDay);
    }

    const entity = {
      ...feedingPlanEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          diet: 'DRY_FOOD',
          ...feedingPlanEntity,
          pet: feedingPlanEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.feedingPlan.home.createOrEditLabel" data-cy="FeedingPlanCreateUpdateHeading">
            Create or edit a Feeding Plan
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="feeding-plan-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField label="Diet" id="feeding-plan-diet" name="diet" data-cy="diet" type="select">
                {dietTypeValues.map(dietType => (
                  <option value={dietType} key={dietType}>
                    {dietType}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Food Brand"
                id="feeding-plan-foodBrand"
                name="foodBrand"
                data-cy="foodBrand"
                type="text"
                validate={{
                  maxLength: { value: 80, message: 'This field cannot be longer than 80 characters.' },
                }}
              />
              <ValidatedField
                label="Amount Grams"
                id="feeding-plan-amountGrams"
                name="amountGrams"
                data-cy="amountGrams"
                type="text"
                validate={{
                  min: { value: 0, message: 'This field should be at least 0.' },
                  max: { value: 5000, message: 'This field cannot be more than 5000.' },
                  validate: v => isNumber(v) || 'This field should be a number.',
                }}
              />
              <ValidatedField
                label="Frequency Per Day"
                id="feeding-plan-frequencyPerDay"
                name="frequencyPerDay"
                data-cy="frequencyPerDay"
                type="text"
                validate={{
                  min: { value: 1, message: 'This field should be at least 1.' },
                  max: { value: 6, message: 'This field cannot be more than 6.' },
                  validate: v => isNumber(v) || 'This field should be a number.',
                }}
              />
              <ValidatedField
                label="Special Instructions"
                id="feeding-plan-specialInstructions"
                name="specialInstructions"
                data-cy="specialInstructions"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="feeding-plan-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/feeding-plan" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default FeedingPlanUpdate;
