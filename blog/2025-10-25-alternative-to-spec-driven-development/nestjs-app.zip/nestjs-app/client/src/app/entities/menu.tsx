import React from 'react';

import MenuItem from 'app/shared/layout/menus/menu-item';

const EntitiesMenu = () => {
  return (
    <>
      {/* prettier-ignore */}
      <MenuItem icon="asterisk" to="/breed">
        Breed
      </MenuItem>
      <MenuItem icon="asterisk" to="/person">
        Person
      </MenuItem>
      <MenuItem icon="asterisk" to="/enclosure">
        Enclosure
      </MenuItem>
      <MenuItem icon="asterisk" to="/housing-assignment">
        Housing Assignment
      </MenuItem>
      <MenuItem icon="asterisk" to="/intake-record">
        Intake Record
      </MenuItem>
      <MenuItem icon="asterisk" to="/pet">
        Pet
      </MenuItem>
      <MenuItem icon="asterisk" to="/pet-status-change">
        Pet Status Change
      </MenuItem>
      <MenuItem icon="asterisk" to="/vaccination-record">
        Vaccination Record
      </MenuItem>
      <MenuItem icon="asterisk" to="/medical-condition">
        Medical Condition
      </MenuItem>
      <MenuItem icon="asterisk" to="/vet-visit">
        Vet Visit
      </MenuItem>
      <MenuItem icon="asterisk" to="/treatment">
        Treatment
      </MenuItem>
      <MenuItem icon="asterisk" to="/feeding-plan">
        Feeding Plan
      </MenuItem>
      <MenuItem icon="asterisk" to="/photo">
        Photo
      </MenuItem>
      <MenuItem icon="asterisk" to="/adoption-application">
        Adoption Application
      </MenuItem>
      <MenuItem icon="asterisk" to="/ownership">
        Ownership
      </MenuItem>
      {/* jhipster-needle-add-entity-to-menu - JHipster will add entities to the menu here */}
    </>
  );
};

export default EntitiesMenu;
