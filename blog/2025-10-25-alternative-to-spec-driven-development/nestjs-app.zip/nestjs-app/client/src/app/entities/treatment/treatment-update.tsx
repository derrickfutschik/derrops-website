import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { getEntities as getMedicalConditions } from 'app/entities/medical-condition/medical-condition.reducer';
import { TreatmentType } from 'app/shared/model/enumerations/treatment-type.model';
import { createEntity, getEntity, reset, updateEntity } from './treatment.reducer';

export const TreatmentUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const pets = useAppSelector(state => state.pet.entities);
  const medicalConditions = useAppSelector(state => state.medicalCondition.entities);
  const treatmentEntity = useAppSelector(state => state.treatment.entity);
  const loading = useAppSelector(state => state.treatment.loading);
  const updating = useAppSelector(state => state.treatment.updating);
  const updateSuccess = useAppSelector(state => state.treatment.updateSuccess);
  const treatmentTypeValues = Object.keys(TreatmentType);

  const handleClose = () => {
    navigate(`/treatment${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getPets({}));
    dispatch(getMedicalConditions({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }

    const entity = {
      ...treatmentEntity,
      ...values,
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
      condition: medicalConditions.find(it => it.id.toString() === values.condition?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {}
      : {
          type: 'SURGERY',
          ...treatmentEntity,
          pet: treatmentEntity?.pet?.id,
          condition: treatmentEntity?.condition?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.treatment.home.createOrEditLabel" data-cy="TreatmentCreateUpdateHeading">
            Create or edit a Treatment
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? <ValidatedField name="id" required readOnly id="treatment-id" label="ID" validate={{ required: true }} /> : null}
              <ValidatedField label="Type" id="treatment-type" name="type" data-cy="type" type="select">
                {treatmentTypeValues.map(treatmentType => (
                  <option value={treatmentType} key={treatmentType}>
                    {treatmentType}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Name"
                id="treatment-name"
                name="name"
                data-cy="name"
                type="text"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                  minLength: { value: 2, message: 'This field is required to be at least 2 characters.' },
                  maxLength: { value: 80, message: 'This field cannot be longer than 80 characters.' },
                }}
              />
              <ValidatedField label="Start Date" id="treatment-startDate" name="startDate" data-cy="startDate" type="date" />
              <ValidatedField label="End Date" id="treatment-endDate" name="endDate" data-cy="endDate" type="date" />
              <ValidatedField
                label="Dosage"
                id="treatment-dosage"
                name="dosage"
                data-cy="dosage"
                type="text"
                validate={{
                  maxLength: { value: 80, message: 'This field cannot be longer than 80 characters.' },
                }}
              />
              <ValidatedField
                label="Instructions"
                id="treatment-instructions"
                name="instructions"
                data-cy="instructions"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="treatment-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="treatment-condition" name="condition" data-cy="condition" label="Condition" type="select">
                <option value="" key="0" />
                {medicalConditions
                  ? medicalConditions.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/treatment" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default TreatmentUpdate;
