import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import {} from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './enclosure.reducer';

export const EnclosureDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const enclosureEntity = useAppSelector(state => state.enclosure.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="enclosureDetailsHeading">Enclosure</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{enclosureEntity.id}</dd>
          <dt>
            <span id="code">Code</span>
          </dt>
          <dd>{enclosureEntity.code}</dd>
          <dt>
            <span id="type">Type</span>
          </dt>
          <dd>{enclosureEntity.type}</dd>
          <dt>
            <span id="capacity">Capacity</span>
          </dt>
          <dd>{enclosureEntity.capacity}</dd>
          <dt>
            <span id="location">Location</span>
          </dt>
          <dd>{enclosureEntity.location}</dd>
          <dt>
            <span id="notes">Notes</span>
          </dt>
          <dd>{enclosureEntity.notes}</dd>
        </dl>
        <Button tag={Link} to="/enclosure" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/enclosure/${enclosureEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default EnclosureDetail;
