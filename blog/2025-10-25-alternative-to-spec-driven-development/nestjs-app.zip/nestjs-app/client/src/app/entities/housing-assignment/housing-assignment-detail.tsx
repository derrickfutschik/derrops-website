import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_LOCAL_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './housing-assignment.reducer';

export const HousingAssignmentDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const housingAssignmentEntity = useAppSelector(state => state.housingAssignment.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="housingAssignmentDetailsHeading">Housing Assignment</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{housingAssignmentEntity.id}</dd>
          <dt>
            <span id="startDate">Start Date</span>
          </dt>
          <dd>
            {housingAssignmentEntity.startDate ? (
              <TextFormat value={housingAssignmentEntity.startDate} type="date" format={APP_LOCAL_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>
            <span id="endDate">End Date</span>
          </dt>
          <dd>
            {housingAssignmentEntity.endDate ? (
              <TextFormat value={housingAssignmentEntity.endDate} type="date" format={APP_LOCAL_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>Pet</dt>
          <dd>{housingAssignmentEntity.pet ? housingAssignmentEntity.pet.name : ''}</dd>
          <dt>Enclosure</dt>
          <dd>{housingAssignmentEntity.enclosure ? housingAssignmentEntity.enclosure.code : ''}</dd>
        </dl>
        <Button tag={Link} to="/housing-assignment" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/housing-assignment/${housingAssignmentEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default HousingAssignmentDetail;
