import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './pet-status-change.reducer';

export const PetStatusChangeDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const petStatusChangeEntity = useAppSelector(state => state.petStatusChange.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="petStatusChangeDetailsHeading">Pet Status Change</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{petStatusChangeEntity.id}</dd>
          <dt>
            <span id="fromStatus">From Status</span>
          </dt>
          <dd>{petStatusChangeEntity.fromStatus}</dd>
          <dt>
            <span id="toStatus">To Status</span>
          </dt>
          <dd>{petStatusChangeEntity.toStatus}</dd>
          <dt>
            <span id="changedAt">Changed At</span>
          </dt>
          <dd>
            {petStatusChangeEntity.changedAt ? (
              <TextFormat value={petStatusChangeEntity.changedAt} type="date" format={APP_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>
            <span id="reason">Reason</span>
          </dt>
          <dd>{petStatusChangeEntity.reason}</dd>
          <dt>Pet</dt>
          <dd>{petStatusChangeEntity.pet ? petStatusChangeEntity.pet.name : ''}</dd>
        </dl>
        <Button tag={Link} to="/pet-status-change" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/pet-status-change/${petStatusChangeEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default PetStatusChangeDetail;
