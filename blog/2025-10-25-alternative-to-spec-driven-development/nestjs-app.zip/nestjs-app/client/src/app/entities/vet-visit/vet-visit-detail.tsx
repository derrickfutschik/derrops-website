import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './vet-visit.reducer';

export const VetVisitDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const vetVisitEntity = useAppSelector(state => state.vetVisit.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="vetVisitDetailsHeading">Vet Visit</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{vetVisitEntity.id}</dd>
          <dt>
            <span id="visitDate">Visit Date</span>
          </dt>
          <dd>{vetVisitEntity.visitDate ? <TextFormat value={vetVisitEntity.visitDate} type="date" format={APP_DATE_FORMAT} /> : null}</dd>
          <dt>
            <span id="clinicName">Clinic Name</span>
          </dt>
          <dd>{vetVisitEntity.clinicName}</dd>
          <dt>
            <span id="vetName">Vet Name</span>
          </dt>
          <dd>{vetVisitEntity.vetName}</dd>
          <dt>
            <span id="reason">Reason</span>
          </dt>
          <dd>{vetVisitEntity.reason}</dd>
          <dt>
            <span id="report">Report</span>
          </dt>
          <dd>{vetVisitEntity.report}</dd>
          <dt>Pet</dt>
          <dd>{vetVisitEntity.pet ? vetVisitEntity.pet.name : ''}</dd>
        </dl>
        <Button tag={Link} to="/vet-visit" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/vet-visit/${vetVisitEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default VetVisitDetail;
