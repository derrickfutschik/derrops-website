import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_LOCAL_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './intake-record.reducer';

export const IntakeRecordDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const intakeRecordEntity = useAppSelector(state => state.intakeRecord.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="intakeRecordDetailsHeading">Intake Record</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{intakeRecordEntity.id}</dd>
          <dt>
            <span id="intakeDate">Intake Date</span>
          </dt>
          <dd>
            {intakeRecordEntity.intakeDate ? (
              <TextFormat value={intakeRecordEntity.intakeDate} type="date" format={APP_LOCAL_DATE_FORMAT} />
            ) : null}
          </dd>
          <dt>
            <span id="source">Source</span>
          </dt>
          <dd>{intakeRecordEntity.source}</dd>
          <dt>
            <span id="foundLocation">Found Location</span>
          </dt>
          <dd>{intakeRecordEntity.foundLocation}</dd>
          <dt>
            <span id="surrenderedReason">Surrendered Reason</span>
          </dt>
          <dd>{intakeRecordEntity.surrenderedReason}</dd>
          <dt>
            <span id="initialHealthNotes">Initial Health Notes</span>
          </dt>
          <dd>{intakeRecordEntity.initialHealthNotes}</dd>
          <dt>Pet</dt>
          <dd>{intakeRecordEntity.pet ? intakeRecordEntity.pet.name : ''}</dd>
        </dl>
        <Button tag={Link} to="/intake-record" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/intake-record/${intakeRecordEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default IntakeRecordDetail;
