import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { ValidatedField, ValidatedForm } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntities as getPeople } from 'app/entities/person/person.reducer';
import { getEntities as getPets } from 'app/entities/pet/pet.reducer';
import { ApplicationStatus } from 'app/shared/model/enumerations/application-status.model';
import { createEntity, getEntity, reset, updateEntity } from './adoption-application.reducer';

export const AdoptionApplicationUpdate = () => {
  const dispatch = useAppDispatch();

  const navigate = useNavigate();

  const { id } = useParams<'id'>();
  const isNew = id === undefined;

  const people = useAppSelector(state => state.person.entities);
  const pets = useAppSelector(state => state.pet.entities);
  const adoptionApplicationEntity = useAppSelector(state => state.adoptionApplication.entity);
  const loading = useAppSelector(state => state.adoptionApplication.loading);
  const updating = useAppSelector(state => state.adoptionApplication.updating);
  const updateSuccess = useAppSelector(state => state.adoptionApplication.updateSuccess);
  const applicationStatusValues = Object.keys(ApplicationStatus);

  const handleClose = () => {
    navigate(`/adoption-application${location.search}`);
  };

  useEffect(() => {
    if (isNew) {
      dispatch(reset());
    } else {
      dispatch(getEntity(id));
    }

    dispatch(getPeople({}));
    dispatch(getPets({}));
  }, []);

  useEffect(() => {
    if (updateSuccess) {
      handleClose();
    }
  }, [updateSuccess]);

  const saveEntity = values => {
    if (values.id !== undefined && typeof values.id !== 'number') {
      values.id = Number(values.id);
    }
    values.submittedDate = convertDateTimeToServer(values.submittedDate);

    const entity = {
      ...adoptionApplicationEntity,
      ...values,
      applicant: people.find(it => it.id.toString() === values.applicant?.toString()),
      pet: pets.find(it => it.id.toString() === values.pet?.toString()),
    };

    if (isNew) {
      dispatch(createEntity(entity));
    } else {
      dispatch(updateEntity(entity));
    }
  };

  const defaultValues = () =>
    isNew
      ? {
          submittedDate: displayDefaultDateTime(),
        }
      : {
          status: 'SUBMITTED',
          ...adoptionApplicationEntity,
          submittedDate: convertDateTimeFromServer(adoptionApplicationEntity.submittedDate),
          applicant: adoptionApplicationEntity?.applicant?.id,
          pet: adoptionApplicationEntity?.pet?.id,
        };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="petstoreApp.adoptionApplication.home.createOrEditLabel" data-cy="AdoptionApplicationCreateUpdateHeading">
            Create or edit a Adoption Application
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <ValidatedForm defaultValues={defaultValues()} onSubmit={saveEntity}>
              {!isNew ? (
                <ValidatedField name="id" required readOnly id="adoption-application-id" label="ID" validate={{ required: true }} />
              ) : null}
              <ValidatedField
                label="Submitted Date"
                id="adoption-application-submittedDate"
                name="submittedDate"
                data-cy="submittedDate"
                type="datetime-local"
                placeholder="YYYY-MM-DD HH:mm"
                validate={{
                  required: { value: true, message: 'This field is required.' },
                }}
              />
              <ValidatedField label="Status" id="adoption-application-status" name="status" data-cy="status" type="select">
                {applicationStatusValues.map(applicationStatus => (
                  <option value={applicationStatus} key={applicationStatus}>
                    {applicationStatus}
                  </option>
                ))}
              </ValidatedField>
              <ValidatedField
                label="Notes"
                id="adoption-application-notes"
                name="notes"
                data-cy="notes"
                type="text"
                validate={{
                  maxLength: { value: 5000, message: 'This field cannot be longer than 5000 characters.' },
                }}
              />
              <ValidatedField id="adoption-application-applicant" name="applicant" data-cy="applicant" label="Applicant" type="select">
                <option value="" key="0" />
                {people
                  ? people.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.lastName}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <ValidatedField id="adoption-application-pet" name="pet" data-cy="pet" label="Pet" type="select">
                <option value="" key="0" />
                {pets
                  ? pets.map(otherEntity => (
                      <option value={otherEntity.id} key={otherEntity.id}>
                        {otherEntity.name}
                      </option>
                    ))
                  : null}
              </ValidatedField>
              <Button tag={Link} id="cancel-save" data-cy="entityCreateCancelButton" to="/adoption-application" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">Back</span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" data-cy="entityCreateSaveButton" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp; Save
              </Button>
            </ValidatedForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default AdoptionApplicationUpdate;
