import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button, Col, Row } from 'reactstrap';
import { TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { APP_LOCAL_DATE_FORMAT } from 'app/config/constants';
import { useAppDispatch, useAppSelector } from 'app/config/store';

import { getEntity } from './treatment.reducer';

export const TreatmentDetail = () => {
  const dispatch = useAppDispatch();

  const { id } = useParams<'id'>();

  useEffect(() => {
    dispatch(getEntity(id));
  }, []);

  const treatmentEntity = useAppSelector(state => state.treatment.entity);
  return (
    <Row>
      <Col md="8">
        <h2 data-cy="treatmentDetailsHeading">Treatment</h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="id">ID</span>
          </dt>
          <dd>{treatmentEntity.id}</dd>
          <dt>
            <span id="type">Type</span>
          </dt>
          <dd>{treatmentEntity.type}</dd>
          <dt>
            <span id="name">Name</span>
          </dt>
          <dd>{treatmentEntity.name}</dd>
          <dt>
            <span id="startDate">Start Date</span>
          </dt>
          <dd>
            {treatmentEntity.startDate ? <TextFormat value={treatmentEntity.startDate} type="date" format={APP_LOCAL_DATE_FORMAT} /> : null}
          </dd>
          <dt>
            <span id="endDate">End Date</span>
          </dt>
          <dd>
            {treatmentEntity.endDate ? <TextFormat value={treatmentEntity.endDate} type="date" format={APP_LOCAL_DATE_FORMAT} /> : null}
          </dd>
          <dt>
            <span id="dosage">Dosage</span>
          </dt>
          <dd>{treatmentEntity.dosage}</dd>
          <dt>
            <span id="instructions">Instructions</span>
          </dt>
          <dd>{treatmentEntity.instructions}</dd>
          <dt>Pet</dt>
          <dd>{treatmentEntity.pet ? treatmentEntity.pet.name : ''}</dd>
          <dt>Condition</dt>
          <dd>{treatmentEntity.condition ? treatmentEntity.condition.name : ''}</dd>
        </dl>
        <Button tag={Link} to="/treatment" replace color="info" data-cy="entityDetailsBackButton">
          <FontAwesomeIcon icon="arrow-left" /> <span className="d-none d-md-inline">Back</span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/treatment/${treatmentEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" /> <span className="d-none d-md-inline">Edit</span>
        </Button>
      </Col>
    </Row>
  );
};

export default TreatmentDetail;
