import React from 'react';
import { Route } from 'react-router';

import ErrorBoundaryRoutes from 'app/shared/error/error-boundary-routes';

import FeedingPlan from './feeding-plan';
import FeedingPlanDetail from './feeding-plan-detail';
import FeedingPlanUpdate from './feeding-plan-update';
import FeedingPlanDeleteDialog from './feeding-plan-delete-dialog';

const FeedingPlanRoutes = () => (
  <ErrorBoundaryRoutes>
    <Route index element={<FeedingPlan />} />
    <Route path="new" element={<FeedingPlanUpdate />} />
    <Route path=":id">
      <Route index element={<FeedingPlanDetail />} />
      <Route path="edit" element={<FeedingPlanUpdate />} />
      <Route path="delete" element={<FeedingPlanDeleteDialog />} />
    </Route>
  </ErrorBoundaryRoutes>
);

export default FeedingPlanRoutes;
