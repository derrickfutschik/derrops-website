import { SpeciesType } from 'app/shared/model/enumerations/species-type.model';

export interface IBreed {
  id?: number;
  name?: string;
  species?: keyof typeof SpeciesType;
  sizeLabel?: string | null;
  notes?: string | null;
}

export const defaultValue: Readonly<IBreed> = {};
