import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';

export interface IVetVisit {
  id?: number;
  visitDate?: dayjs.Dayjs;
  clinicName?: string | null;
  vetName?: string | null;
  reason?: string | null;
  report?: string | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IVetVisit> = {};
