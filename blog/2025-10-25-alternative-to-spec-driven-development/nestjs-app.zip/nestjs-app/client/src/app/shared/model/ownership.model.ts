import dayjs from 'dayjs';
import { IPerson } from 'app/shared/model/person.model';
import { IPet } from 'app/shared/model/pet.model';
import { OwnershipType } from 'app/shared/model/enumerations/ownership-type.model';

export interface IOwnership {
  id?: number;
  type?: keyof typeof OwnershipType;
  startDate?: dayjs.Dayjs;
  endDate?: dayjs.Dayjs | null;
  owner?: IPerson | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IOwnership> = {};
