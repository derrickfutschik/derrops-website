import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';
import { IEnclosure } from 'app/shared/model/enclosure.model';

export interface IHousingAssignment {
  id?: number;
  startDate?: dayjs.Dayjs;
  endDate?: dayjs.Dayjs | null;
  pet?: IPet | null;
  enclosure?: IEnclosure | null;
}

export const defaultValue: Readonly<IHousingAssignment> = {};
