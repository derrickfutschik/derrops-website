import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';
import { IMedicalCondition } from 'app/shared/model/medical-condition.model';
import { TreatmentType } from 'app/shared/model/enumerations/treatment-type.model';

export interface ITreatment {
  id?: number;
  type?: keyof typeof TreatmentType;
  name?: string;
  startDate?: dayjs.Dayjs | null;
  endDate?: dayjs.Dayjs | null;
  dosage?: string | null;
  instructions?: string | null;
  pet?: IPet | null;
  condition?: IMedicalCondition | null;
}

export const defaultValue: Readonly<ITreatment> = {};
