import dayjs from 'dayjs';
import { IPerson } from 'app/shared/model/person.model';
import { IPet } from 'app/shared/model/pet.model';
import { ApplicationStatus } from 'app/shared/model/enumerations/application-status.model';

export interface IAdoptionApplication {
  id?: number;
  submittedDate?: dayjs.Dayjs;
  status?: keyof typeof ApplicationStatus;
  notes?: string | null;
  applicant?: IPerson | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IAdoptionApplication> = {};
