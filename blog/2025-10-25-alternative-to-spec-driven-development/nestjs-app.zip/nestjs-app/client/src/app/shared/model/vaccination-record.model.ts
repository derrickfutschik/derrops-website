import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';
import { Vaccine } from 'app/shared/model/enumerations/vaccine.model';

export interface IVaccinationRecord {
  id?: number;
  vaccine?: keyof typeof Vaccine;
  dateGiven?: dayjs.Dayjs;
  dueDate?: dayjs.Dayjs | null;
  administeredBy?: string | null;
  notes?: string | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IVaccinationRecord> = {};
