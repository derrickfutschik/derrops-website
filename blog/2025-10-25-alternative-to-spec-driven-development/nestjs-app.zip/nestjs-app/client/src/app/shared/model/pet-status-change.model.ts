import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';
import { PetStatus } from 'app/shared/model/enumerations/pet-status.model';

export interface IPetStatusChange {
  id?: number;
  fromStatus?: keyof typeof PetStatus;
  toStatus?: keyof typeof PetStatus;
  changedAt?: dayjs.Dayjs;
  reason?: string | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IPetStatusChange> = {};
