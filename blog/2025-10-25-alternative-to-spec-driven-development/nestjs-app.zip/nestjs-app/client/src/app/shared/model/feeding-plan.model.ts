import { IPet } from 'app/shared/model/pet.model';
import { DietType } from 'app/shared/model/enumerations/diet-type.model';

export interface IFeedingPlan {
  id?: number;
  diet?: keyof typeof DietType;
  foodBrand?: string | null;
  amountGrams?: number | null;
  frequencyPerDay?: number | null;
  specialInstructions?: string | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IFeedingPlan> = {};
