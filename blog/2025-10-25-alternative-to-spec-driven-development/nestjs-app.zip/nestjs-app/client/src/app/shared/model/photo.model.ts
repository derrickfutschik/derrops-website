import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';

export interface IPhoto {
  id?: number;
  imageDataContentType?: string;
  imageData?: string;
  caption?: string | null;
  takenAt?: dayjs.Dayjs | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IPhoto> = {};
