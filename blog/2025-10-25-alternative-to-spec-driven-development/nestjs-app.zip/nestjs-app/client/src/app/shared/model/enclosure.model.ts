import { EnclosureType } from 'app/shared/model/enumerations/enclosure-type.model';

export interface IEnclosure {
  id?: number;
  code?: string;
  type?: keyof typeof EnclosureType;
  capacity?: number;
  location?: string | null;
  notes?: string | null;
}

export const defaultValue: Readonly<IEnclosure> = {};
