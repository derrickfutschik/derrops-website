import dayjs from 'dayjs';
import { IBreed } from 'app/shared/model/breed.model';
import { IEnclosure } from 'app/shared/model/enclosure.model';
import { SpeciesType } from 'app/shared/model/enumerations/species-type.model';
import { Sex } from 'app/shared/model/enumerations/sex.model';
import { PetStatus } from 'app/shared/model/enumerations/pet-status.model';
import { Temperament } from 'app/shared/model/enumerations/temperament.model';

export interface IPet {
  id?: number;
  name?: string;
  species?: keyof typeof SpeciesType;
  sex?: keyof typeof Sex;
  dateOfBirth?: dayjs.Dayjs | null;
  estimatedAgeMonths?: number | null;
  color?: string | null;
  microchipNumber?: string | null;
  intakeDate?: dayjs.Dayjs;
  status?: keyof typeof PetStatus;
  neutered?: boolean;
  weightKg?: number | null;
  temperament?: keyof typeof Temperament | null;
  description?: string | null;
  breed?: IBreed | null;
  enclosure?: IEnclosure | null;
}

export const defaultValue: Readonly<IPet> = {
  neutered: false,
};
