import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';
import { IntakeSource } from 'app/shared/model/enumerations/intake-source.model';

export interface IIntakeRecord {
  id?: number;
  intakeDate?: dayjs.Dayjs;
  source?: keyof typeof IntakeSource;
  foundLocation?: string | null;
  surrenderedReason?: string | null;
  initialHealthNotes?: string | null;
  pet?: IPet;
}

export const defaultValue: Readonly<IIntakeRecord> = {};
