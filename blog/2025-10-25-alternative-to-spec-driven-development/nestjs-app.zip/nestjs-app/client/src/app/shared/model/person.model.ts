export interface IPerson {
  id?: number;
  firstName?: string;
  lastName?: string;
  phone?: string | null;
  email?: string | null;
  street?: string | null;
  city?: string | null;
  state?: string | null;
  postalCode?: string | null;
  country?: string | null;
  verified?: boolean | null;
}

export const defaultValue: Readonly<IPerson> = {
  verified: false,
};
