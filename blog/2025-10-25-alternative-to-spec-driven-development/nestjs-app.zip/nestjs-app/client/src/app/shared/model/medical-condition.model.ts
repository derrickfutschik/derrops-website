import dayjs from 'dayjs';
import { IPet } from 'app/shared/model/pet.model';

export interface IMedicalCondition {
  id?: number;
  name?: string;
  description?: string | null;
  chronic?: boolean | null;
  diagnosedDate?: dayjs.Dayjs | null;
  pet?: IPet | null;
}

export const defaultValue: Readonly<IMedicalCondition> = {
  chronic: false,
};
