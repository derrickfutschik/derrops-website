import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServeStaticModule } from '@nestjs/serve-static';
import { AuthModule } from './module/auth.module';
import { ormConfig } from './orm.config';
import { config } from './config';
import { BreedModule } from './module/breed.module';
import { PersonModule } from './module/person.module';
import { EnclosureModule } from './module/enclosure.module';
import { HousingAssignmentModule } from './module/housing-assignment.module';
import { IntakeRecordModule } from './module/intake-record.module';
import { PetModule } from './module/pet.module';
import { PetStatusChangeModule } from './module/pet-status-change.module';
import { VaccinationRecordModule } from './module/vaccination-record.module';
import { MedicalConditionModule } from './module/medical-condition.module';
import { VetVisitModule } from './module/vet-visit.module';
import { TreatmentModule } from './module/treatment.module';
import { FeedingPlanModule } from './module/feeding-plan.module';
import { PhotoModule } from './module/photo.module';
import { AdoptionApplicationModule } from './module/adoption-application.module';
import { OwnershipModule } from './module/ownership.module';
// jhipster-needle-add-entity-module-to-main-import - JHipster will import entity modules here, do not remove
// jhipster-needle-add-controller-module-to-main-import - JHipster will import controller modules here, do not remove
// jhipster-needle-add-service-module-to-main-import - JHipster will import service modules here, do not remove

@Module({
  imports: [
    TypeOrmModule.forRootAsync({ useFactory: ormConfig }),
    ServeStaticModule.forRoot({
      rootPath: config.getClientPath(),
    }),
    AuthModule,
    BreedModule,
    PersonModule,
    EnclosureModule,
    HousingAssignmentModule,
    IntakeRecordModule,
    PetModule,
    PetStatusChangeModule,
    VaccinationRecordModule,
    MedicalConditionModule,
    VetVisitModule,
    TreatmentModule,
    FeedingPlanModule,
    PhotoModule,
    AdoptionApplicationModule,
    OwnershipModule,
    // jhipster-needle-add-entity-module-to-main - JHipster will add entity modules here, do not remove
  ],
  controllers: [
    // jhipster-needle-add-controller-module-to-main - JHipster will add controller modules here, do not remove
  ],
  providers: [
    // jhipster-needle-add-service-module-to-main - JHipster will add service modules here, do not remove
  ],
})
export class AppModule {}
