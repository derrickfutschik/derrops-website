import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { IntakeRecordDTO } from '../../service/dto/intake-record.dto';
import { IntakeRecordService } from '../../service/intake-record.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/intake-records')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('intake-records')
export class IntakeRecordController {
  logger = new Logger('IntakeRecordController');

  constructor(private readonly intakeRecordService: IntakeRecordService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: IntakeRecordDTO,
  })
  async getAll(@Req() req: Request): Promise<IntakeRecordDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.intakeRecordService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: IntakeRecordDTO,
  })
  async getOne(@Param('id') id: number): Promise<IntakeRecordDTO> {
    return await this.intakeRecordService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create intakeRecord' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: IntakeRecordDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() intakeRecordDTO: IntakeRecordDTO): Promise<IntakeRecordDTO> {
    const created = await this.intakeRecordService.save(intakeRecordDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'IntakeRecord', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update intakeRecord' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: IntakeRecordDTO,
  })
  async put(@Req() req: Request, @Body() intakeRecordDTO: IntakeRecordDTO): Promise<IntakeRecordDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'IntakeRecord', intakeRecordDTO.id);
    return await this.intakeRecordService.update(intakeRecordDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update intakeRecord with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: IntakeRecordDTO,
  })
  async putId(@Req() req: Request, @Body() intakeRecordDTO: IntakeRecordDTO): Promise<IntakeRecordDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'IntakeRecord', intakeRecordDTO.id);
    return await this.intakeRecordService.update(intakeRecordDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete intakeRecord' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'IntakeRecord', id);
    return await this.intakeRecordService.deleteById(id);
  }
}
