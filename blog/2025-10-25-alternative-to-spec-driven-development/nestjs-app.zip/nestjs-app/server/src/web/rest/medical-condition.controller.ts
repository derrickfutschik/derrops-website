import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { MedicalConditionDTO } from '../../service/dto/medical-condition.dto';
import { MedicalConditionService } from '../../service/medical-condition.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/medical-conditions')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('medical-conditions')
export class MedicalConditionController {
  logger = new Logger('MedicalConditionController');

  constructor(private readonly medicalConditionService: MedicalConditionService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: MedicalConditionDTO,
  })
  async getAll(@Req() req: Request): Promise<MedicalConditionDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.medicalConditionService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: MedicalConditionDTO,
  })
  async getOne(@Param('id') id: number): Promise<MedicalConditionDTO> {
    return await this.medicalConditionService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create medicalCondition' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: MedicalConditionDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() medicalConditionDTO: MedicalConditionDTO): Promise<MedicalConditionDTO> {
    const created = await this.medicalConditionService.save(medicalConditionDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'MedicalCondition', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update medicalCondition' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: MedicalConditionDTO,
  })
  async put(@Req() req: Request, @Body() medicalConditionDTO: MedicalConditionDTO): Promise<MedicalConditionDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'MedicalCondition', medicalConditionDTO.id);
    return await this.medicalConditionService.update(medicalConditionDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update medicalCondition with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: MedicalConditionDTO,
  })
  async putId(@Req() req: Request, @Body() medicalConditionDTO: MedicalConditionDTO): Promise<MedicalConditionDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'MedicalCondition', medicalConditionDTO.id);
    return await this.medicalConditionService.update(medicalConditionDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete medicalCondition' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'MedicalCondition', id);
    return await this.medicalConditionService.deleteById(id);
  }
}
