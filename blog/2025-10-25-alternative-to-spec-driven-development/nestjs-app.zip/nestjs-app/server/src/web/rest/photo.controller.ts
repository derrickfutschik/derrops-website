import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { PhotoDTO } from '../../service/dto/photo.dto';
import { PhotoService } from '../../service/photo.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/photos')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('photos')
export class PhotoController {
  logger = new Logger('PhotoController');

  constructor(private readonly photoService: PhotoService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: PhotoDTO,
  })
  async getAll(@Req() req: Request): Promise<PhotoDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.photoService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: PhotoDTO,
  })
  async getOne(@Param('id') id: number): Promise<PhotoDTO> {
    return await this.photoService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create photo' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: PhotoDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() photoDTO: PhotoDTO): Promise<PhotoDTO> {
    const created = await this.photoService.save(photoDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Photo', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update photo' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: PhotoDTO,
  })
  async put(@Req() req: Request, @Body() photoDTO: PhotoDTO): Promise<PhotoDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Photo', photoDTO.id);
    return await this.photoService.update(photoDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update photo with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: PhotoDTO,
  })
  async putId(@Req() req: Request, @Body() photoDTO: PhotoDTO): Promise<PhotoDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Photo', photoDTO.id);
    return await this.photoService.update(photoDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete photo' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'Photo', id);
    return await this.photoService.deleteById(id);
  }
}
