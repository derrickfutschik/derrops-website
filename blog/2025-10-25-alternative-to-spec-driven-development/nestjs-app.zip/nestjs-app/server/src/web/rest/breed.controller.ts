import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { BreedDTO } from '../../service/dto/breed.dto';
import { BreedService } from '../../service/breed.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/breeds')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('breeds')
export class BreedController {
  logger = new Logger('BreedController');

  constructor(private readonly breedService: BreedService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: BreedDTO,
  })
  async getAll(@Req() req: Request): Promise<BreedDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.breedService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: BreedDTO,
  })
  async getOne(@Param('id') id: number): Promise<BreedDTO> {
    return await this.breedService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create breed' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: BreedDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() breedDTO: BreedDTO): Promise<BreedDTO> {
    const created = await this.breedService.save(breedDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Breed', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update breed' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: BreedDTO,
  })
  async put(@Req() req: Request, @Body() breedDTO: BreedDTO): Promise<BreedDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Breed', breedDTO.id);
    return await this.breedService.update(breedDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update breed with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: BreedDTO,
  })
  async putId(@Req() req: Request, @Body() breedDTO: BreedDTO): Promise<BreedDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Breed', breedDTO.id);
    return await this.breedService.update(breedDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete breed' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'Breed', id);
    return await this.breedService.deleteById(id);
  }
}
