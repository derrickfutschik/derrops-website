import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { PetStatusChangeDTO } from '../../service/dto/pet-status-change.dto';
import { PetStatusChangeService } from '../../service/pet-status-change.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/pet-status-changes')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('pet-status-changes')
export class PetStatusChangeController {
  logger = new Logger('PetStatusChangeController');

  constructor(private readonly petStatusChangeService: PetStatusChangeService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: PetStatusChangeDTO,
  })
  async getAll(@Req() req: Request): Promise<PetStatusChangeDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.petStatusChangeService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: PetStatusChangeDTO,
  })
  async getOne(@Param('id') id: number): Promise<PetStatusChangeDTO> {
    return await this.petStatusChangeService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create petStatusChange' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: PetStatusChangeDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() petStatusChangeDTO: PetStatusChangeDTO): Promise<PetStatusChangeDTO> {
    const created = await this.petStatusChangeService.save(petStatusChangeDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'PetStatusChange', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update petStatusChange' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: PetStatusChangeDTO,
  })
  async put(@Req() req: Request, @Body() petStatusChangeDTO: PetStatusChangeDTO): Promise<PetStatusChangeDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'PetStatusChange', petStatusChangeDTO.id);
    return await this.petStatusChangeService.update(petStatusChangeDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update petStatusChange with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: PetStatusChangeDTO,
  })
  async putId(@Req() req: Request, @Body() petStatusChangeDTO: PetStatusChangeDTO): Promise<PetStatusChangeDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'PetStatusChange', petStatusChangeDTO.id);
    return await this.petStatusChangeService.update(petStatusChangeDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete petStatusChange' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'PetStatusChange', id);
    return await this.petStatusChangeService.deleteById(id);
  }
}
