import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { EnclosureDTO } from '../../service/dto/enclosure.dto';
import { EnclosureService } from '../../service/enclosure.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/enclosures')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('enclosures')
export class EnclosureController {
  logger = new Logger('EnclosureController');

  constructor(private readonly enclosureService: EnclosureService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: EnclosureDTO,
  })
  async getAll(@Req() req: Request): Promise<EnclosureDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.enclosureService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: EnclosureDTO,
  })
  async getOne(@Param('id') id: number): Promise<EnclosureDTO> {
    return await this.enclosureService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create enclosure' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: EnclosureDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() enclosureDTO: EnclosureDTO): Promise<EnclosureDTO> {
    const created = await this.enclosureService.save(enclosureDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Enclosure', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update enclosure' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: EnclosureDTO,
  })
  async put(@Req() req: Request, @Body() enclosureDTO: EnclosureDTO): Promise<EnclosureDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Enclosure', enclosureDTO.id);
    return await this.enclosureService.update(enclosureDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update enclosure with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: EnclosureDTO,
  })
  async putId(@Req() req: Request, @Body() enclosureDTO: EnclosureDTO): Promise<EnclosureDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Enclosure', enclosureDTO.id);
    return await this.enclosureService.update(enclosureDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete enclosure' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'Enclosure', id);
    return await this.enclosureService.deleteById(id);
  }
}
