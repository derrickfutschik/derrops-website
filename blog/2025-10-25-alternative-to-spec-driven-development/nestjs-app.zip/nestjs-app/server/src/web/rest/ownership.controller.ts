import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { OwnershipDTO } from '../../service/dto/ownership.dto';
import { OwnershipService } from '../../service/ownership.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/ownerships')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('ownerships')
export class OwnershipController {
  logger = new Logger('OwnershipController');

  constructor(private readonly ownershipService: OwnershipService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: OwnershipDTO,
  })
  async getAll(@Req() req: Request): Promise<OwnershipDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.ownershipService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: OwnershipDTO,
  })
  async getOne(@Param('id') id: number): Promise<OwnershipDTO> {
    return await this.ownershipService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create ownership' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: OwnershipDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() ownershipDTO: OwnershipDTO): Promise<OwnershipDTO> {
    const created = await this.ownershipService.save(ownershipDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Ownership', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update ownership' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: OwnershipDTO,
  })
  async put(@Req() req: Request, @Body() ownershipDTO: OwnershipDTO): Promise<OwnershipDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Ownership', ownershipDTO.id);
    return await this.ownershipService.update(ownershipDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update ownership with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: OwnershipDTO,
  })
  async putId(@Req() req: Request, @Body() ownershipDTO: OwnershipDTO): Promise<OwnershipDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Ownership', ownershipDTO.id);
    return await this.ownershipService.update(ownershipDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete ownership' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'Ownership', id);
    return await this.ownershipService.deleteById(id);
  }
}
