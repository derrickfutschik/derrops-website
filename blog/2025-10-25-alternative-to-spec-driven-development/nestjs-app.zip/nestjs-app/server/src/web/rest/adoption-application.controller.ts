import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AdoptionApplicationDTO } from '../../service/dto/adoption-application.dto';
import { AdoptionApplicationService } from '../../service/adoption-application.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/adoption-applications')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('adoption-applications')
export class AdoptionApplicationController {
  logger = new Logger('AdoptionApplicationController');

  constructor(private readonly adoptionApplicationService: AdoptionApplicationService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: AdoptionApplicationDTO,
  })
  async getAll(@Req() req: Request): Promise<AdoptionApplicationDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.adoptionApplicationService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: AdoptionApplicationDTO,
  })
  async getOne(@Param('id') id: number): Promise<AdoptionApplicationDTO> {
    return await this.adoptionApplicationService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create adoptionApplication' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: AdoptionApplicationDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() adoptionApplicationDTO: AdoptionApplicationDTO): Promise<AdoptionApplicationDTO> {
    const created = await this.adoptionApplicationService.save(adoptionApplicationDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'AdoptionApplication', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update adoptionApplication' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: AdoptionApplicationDTO,
  })
  async put(@Req() req: Request, @Body() adoptionApplicationDTO: AdoptionApplicationDTO): Promise<AdoptionApplicationDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'AdoptionApplication', adoptionApplicationDTO.id);
    return await this.adoptionApplicationService.update(adoptionApplicationDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update adoptionApplication with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: AdoptionApplicationDTO,
  })
  async putId(@Req() req: Request, @Body() adoptionApplicationDTO: AdoptionApplicationDTO): Promise<AdoptionApplicationDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'AdoptionApplication', adoptionApplicationDTO.id);
    return await this.adoptionApplicationService.update(adoptionApplicationDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete adoptionApplication' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'AdoptionApplication', id);
    return await this.adoptionApplicationService.deleteById(id);
  }
}
