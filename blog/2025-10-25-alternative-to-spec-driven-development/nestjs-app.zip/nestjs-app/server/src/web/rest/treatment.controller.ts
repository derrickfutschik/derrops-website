import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { TreatmentDTO } from '../../service/dto/treatment.dto';
import { TreatmentService } from '../../service/treatment.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/treatments')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('treatments')
export class TreatmentController {
  logger = new Logger('TreatmentController');

  constructor(private readonly treatmentService: TreatmentService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: TreatmentDTO,
  })
  async getAll(@Req() req: Request): Promise<TreatmentDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.treatmentService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: TreatmentDTO,
  })
  async getOne(@Param('id') id: number): Promise<TreatmentDTO> {
    return await this.treatmentService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create treatment' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: TreatmentDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() treatmentDTO: TreatmentDTO): Promise<TreatmentDTO> {
    const created = await this.treatmentService.save(treatmentDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Treatment', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update treatment' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: TreatmentDTO,
  })
  async put(@Req() req: Request, @Body() treatmentDTO: TreatmentDTO): Promise<TreatmentDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Treatment', treatmentDTO.id);
    return await this.treatmentService.update(treatmentDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update treatment with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: TreatmentDTO,
  })
  async putId(@Req() req: Request, @Body() treatmentDTO: TreatmentDTO): Promise<TreatmentDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'Treatment', treatmentDTO.id);
    return await this.treatmentService.update(treatmentDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete treatment' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'Treatment', id);
    return await this.treatmentService.deleteById(id);
  }
}
