import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { HousingAssignmentDTO } from '../../service/dto/housing-assignment.dto';
import { HousingAssignmentService } from '../../service/housing-assignment.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/housing-assignments')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('housing-assignments')
export class HousingAssignmentController {
  logger = new Logger('HousingAssignmentController');

  constructor(private readonly housingAssignmentService: HousingAssignmentService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: HousingAssignmentDTO,
  })
  async getAll(@Req() req: Request): Promise<HousingAssignmentDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.housingAssignmentService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: HousingAssignmentDTO,
  })
  async getOne(@Param('id') id: number): Promise<HousingAssignmentDTO> {
    return await this.housingAssignmentService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create housingAssignment' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: HousingAssignmentDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() housingAssignmentDTO: HousingAssignmentDTO): Promise<HousingAssignmentDTO> {
    const created = await this.housingAssignmentService.save(housingAssignmentDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'HousingAssignment', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update housingAssignment' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: HousingAssignmentDTO,
  })
  async put(@Req() req: Request, @Body() housingAssignmentDTO: HousingAssignmentDTO): Promise<HousingAssignmentDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'HousingAssignment', housingAssignmentDTO.id);
    return await this.housingAssignmentService.update(housingAssignmentDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update housingAssignment with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: HousingAssignmentDTO,
  })
  async putId(@Req() req: Request, @Body() housingAssignmentDTO: HousingAssignmentDTO): Promise<HousingAssignmentDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'HousingAssignment', housingAssignmentDTO.id);
    return await this.housingAssignmentService.update(housingAssignmentDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete housingAssignment' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'HousingAssignment', id);
    return await this.housingAssignmentService.deleteById(id);
  }
}
