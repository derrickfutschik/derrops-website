import {
  Body,
  ClassSerializerInterceptor,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  Post as PostMethod,
  Put,
  Req,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { VetVisitDTO } from '../../service/dto/vet-visit.dto';
import { VetVisitService } from '../../service/vet-visit.service';
import { Page, PageRequest } from '../../domain/base/pagination.entity';
import { AuthGuard, RoleType, Roles, RolesGuard } from '../../security';
import { HeaderUtil } from '../../client/header-util';
import { Request } from '../../client/request';
import { LoggingInterceptor } from '../../client/interceptors/logging.interceptor';

@Controller('api/vet-visits')
@UseGuards(AuthGuard, RolesGuard)
@UseInterceptors(LoggingInterceptor, ClassSerializerInterceptor)
@ApiBearerAuth()
@ApiTags('vet-visits')
export class VetVisitController {
  logger = new Logger('VetVisitController');

  constructor(private readonly vetVisitService: VetVisitService) {}

  @Get('/')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'List all records',
    type: VetVisitDTO,
  })
  async getAll(@Req() req: Request): Promise<VetVisitDTO[]> {
    const pageRequest: PageRequest = new PageRequest(req.query.page, req.query.size, req.query.sort ?? 'id,ASC');
    const [results, count] = await this.vetVisitService.findAndCount({
      skip: +pageRequest.page * pageRequest.size,
      take: +pageRequest.size,
      order: pageRequest.sort.asOrder(),
    });
    HeaderUtil.addPaginationHeaders(req.res, new Page(results, count, pageRequest));
    return results;
  }

  @Get('/:id')
  @Roles(RoleType.USER)
  @ApiResponse({
    status: 200,
    description: 'The found record',
    type: VetVisitDTO,
  })
  async getOne(@Param('id') id: number): Promise<VetVisitDTO> {
    return await this.vetVisitService.findById(id);
  }

  @PostMethod('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Create vetVisit' })
  @ApiResponse({
    status: 201,
    description: 'The record has been successfully created.',
    type: VetVisitDTO,
  })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  async post(@Req() req: Request, @Body() vetVisitDTO: VetVisitDTO): Promise<VetVisitDTO> {
    const created = await this.vetVisitService.save(vetVisitDTO, req.user?.login);
    HeaderUtil.addEntityCreatedHeaders(req.res, 'VetVisit', created.id);
    return created;
  }

  @Put('/')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update vetVisit' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: VetVisitDTO,
  })
  async put(@Req() req: Request, @Body() vetVisitDTO: VetVisitDTO): Promise<VetVisitDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'VetVisit', vetVisitDTO.id);
    return await this.vetVisitService.update(vetVisitDTO, req.user?.login);
  }

  @Put('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Update vetVisit with id' })
  @ApiResponse({
    status: 200,
    description: 'The record has been successfully updated.',
    type: VetVisitDTO,
  })
  async putId(@Req() req: Request, @Body() vetVisitDTO: VetVisitDTO): Promise<VetVisitDTO> {
    HeaderUtil.addEntityCreatedHeaders(req.res, 'VetVisit', vetVisitDTO.id);
    return await this.vetVisitService.update(vetVisitDTO, req.user?.login);
  }

  @Delete('/:id')
  @Roles(RoleType.USER)
  @ApiOperation({ summary: 'Delete vetVisit' })
  @ApiResponse({
    status: 204,
    description: 'The record has been successfully deleted.',
  })
  async deleteById(@Req() req: Request, @Param('id') id: number): Promise<void> {
    HeaderUtil.addEntityDeletedHeaders(req.res, 'VetVisit', id);
    return await this.vetVisitService.deleteById(id);
  }
}
