import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VaccinationRecord } from '../domain/vaccination-record.entity';
import { VaccinationRecordController } from '../web/rest/vaccination-record.controller';
import { VaccinationRecordService } from '../service/vaccination-record.service';

@Module({
  imports: [TypeOrmModule.forFeature([VaccinationRecord])],
  controllers: [VaccinationRecordController],
  providers: [VaccinationRecordService],
  exports: [VaccinationRecordService],
})
export class VaccinationRecordModule {}
