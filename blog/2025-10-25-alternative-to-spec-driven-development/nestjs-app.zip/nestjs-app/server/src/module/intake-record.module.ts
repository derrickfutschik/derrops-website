import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { IntakeRecord } from '../domain/intake-record.entity';
import { IntakeRecordController } from '../web/rest/intake-record.controller';
import { IntakeRecordService } from '../service/intake-record.service';

@Module({
  imports: [TypeOrmModule.forFeature([IntakeRecord])],
  controllers: [IntakeRecordController],
  providers: [IntakeRecordService],
  exports: [IntakeRecordService],
})
export class IntakeRecordModule {}
