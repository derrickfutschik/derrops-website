import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PetStatusChange } from '../domain/pet-status-change.entity';
import { PetStatusChangeController } from '../web/rest/pet-status-change.controller';
import { PetStatusChangeService } from '../service/pet-status-change.service';

@Module({
  imports: [TypeOrmModule.forFeature([PetStatusChange])],
  controllers: [PetStatusChangeController],
  providers: [PetStatusChangeService],
  exports: [PetStatusChangeService],
})
export class PetStatusChangeModule {}
