import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FeedingPlan } from '../domain/feeding-plan.entity';
import { FeedingPlanController } from '../web/rest/feeding-plan.controller';
import { FeedingPlanService } from '../service/feeding-plan.service';

@Module({
  imports: [TypeOrmModule.forFeature([FeedingPlan])],
  controllers: [FeedingPlanController],
  providers: [FeedingPlanService],
  exports: [FeedingPlanService],
})
export class FeedingPlanModule {}
