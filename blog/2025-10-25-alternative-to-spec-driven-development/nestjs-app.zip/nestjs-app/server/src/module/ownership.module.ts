import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Ownership } from '../domain/ownership.entity';
import { OwnershipController } from '../web/rest/ownership.controller';
import { OwnershipService } from '../service/ownership.service';

@Module({
  imports: [TypeOrmModule.forFeature([Ownership])],
  controllers: [OwnershipController],
  providers: [OwnershipService],
  exports: [OwnershipService],
})
export class OwnershipModule {}
