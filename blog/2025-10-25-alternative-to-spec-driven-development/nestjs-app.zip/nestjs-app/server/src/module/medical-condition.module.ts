import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MedicalCondition } from '../domain/medical-condition.entity';
import { MedicalConditionController } from '../web/rest/medical-condition.controller';
import { MedicalConditionService } from '../service/medical-condition.service';

@Module({
  imports: [TypeOrmModule.forFeature([MedicalCondition])],
  controllers: [MedicalConditionController],
  providers: [MedicalConditionService],
  exports: [MedicalConditionService],
})
export class MedicalConditionModule {}
