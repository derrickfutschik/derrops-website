import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Breed } from '../domain/breed.entity';
import { BreedController } from '../web/rest/breed.controller';
import { BreedService } from '../service/breed.service';

@Module({
  imports: [TypeOrmModule.forFeature([Breed])],
  controllers: [BreedController],
  providers: [BreedService],
  exports: [BreedService],
})
export class BreedModule {}
