import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HousingAssignment } from '../domain/housing-assignment.entity';
import { HousingAssignmentController } from '../web/rest/housing-assignment.controller';
import { HousingAssignmentService } from '../service/housing-assignment.service';

@Module({
  imports: [TypeOrmModule.forFeature([HousingAssignment])],
  controllers: [HousingAssignmentController],
  providers: [HousingAssignmentService],
  exports: [HousingAssignmentService],
})
export class HousingAssignmentModule {}
