import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Enclosure } from '../domain/enclosure.entity';
import { EnclosureController } from '../web/rest/enclosure.controller';
import { EnclosureService } from '../service/enclosure.service';

@Module({
  imports: [TypeOrmModule.forFeature([Enclosure])],
  controllers: [EnclosureController],
  providers: [EnclosureService],
  exports: [EnclosureService],
})
export class EnclosureModule {}
