import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdoptionApplication } from '../domain/adoption-application.entity';
import { AdoptionApplicationController } from '../web/rest/adoption-application.controller';
import { AdoptionApplicationService } from '../service/adoption-application.service';

@Module({
  imports: [TypeOrmModule.forFeature([AdoptionApplication])],
  controllers: [AdoptionApplicationController],
  providers: [AdoptionApplicationService],
  exports: [AdoptionApplicationService],
})
export class AdoptionApplicationModule {}
