import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VetVisit } from '../domain/vet-visit.entity';
import { VetVisitController } from '../web/rest/vet-visit.controller';
import { VetVisitService } from '../service/vet-visit.service';

@Module({
  imports: [TypeOrmModule.forFeature([VetVisit])],
  controllers: [VetVisitController],
  providers: [VetVisitService],
  exports: [VetVisitService],
})
export class VetVisitModule {}
