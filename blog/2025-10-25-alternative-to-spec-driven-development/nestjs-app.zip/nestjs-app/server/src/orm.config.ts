import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { SeedUsersRoles1570200490072 } from './migrations/1570200490072-SeedUsersRoles';
import { CreateTables1570200270081 } from './migrations/1570200270081-CreateTables';
import { User } from './domain/user.entity';
import { Authority } from './domain/authority.entity';
import { Breed } from './domain/breed.entity';
import { Person } from './domain/person.entity';
import { Enclosure } from './domain/enclosure.entity';
import { HousingAssignment } from './domain/housing-assignment.entity';
import { IntakeRecord } from './domain/intake-record.entity';
import { Pet } from './domain/pet.entity';
import { PetStatusChange } from './domain/pet-status-change.entity';
import { VaccinationRecord } from './domain/vaccination-record.entity';
import { MedicalCondition } from './domain/medical-condition.entity';
import { VetVisit } from './domain/vet-visit.entity';
import { Treatment } from './domain/treatment.entity';
import { FeedingPlan } from './domain/feeding-plan.entity';
import { Photo } from './domain/photo.entity';
import { AdoptionApplication } from './domain/adoption-application.entity';
import { Ownership } from './domain/ownership.entity';
// jhipster-needle-add-entity-to-ormconfig-imports - JHipster will add code here, do not remove

function ormConfig(): TypeOrmModuleOptions {
  let ormconfig: TypeOrmModuleOptions;

  if (process.env.BACKEND_ENV === 'prod') {
    ormconfig = {
      name: 'default',
      type: 'postgres',
      // typeorm fails to auto load driver due to workspaces resolution
      driver: require('pg'),
      database: 'petstore',
      host: 'postgresql',
      // port: ,
      username: 'petstore',
      password: '',
      logging: false,
      // synchronize: false,
    };
  } else if (process.env.BACKEND_ENV === 'test') {
    ormconfig = {
      name: 'default',
      type: 'sqlite',
      // typeorm fails to auto load driver due to workspaces resolution
      driver: require('sqlite3'),
      database: ':memory:',
      logging: true,
    };
  } else if (process.env.BACKEND_ENV === 'dev') {
    ormconfig = {
      name: 'default',
      type: 'postgres',
      // typeorm fails to auto load driver due to workspaces resolution
      driver: require('sqlite3'),
      database: 'petstore',
      host: '127.0.0.1',
      // port: ,
      username: 'petstore',
      password: '',
      logging: false,
    };
  } else {
    ormconfig = {
      name: 'default',
      type: 'sqlite',
      // typeorm fails to auto load driver due to workspaces resolution
      driver: require('sqlite3'),
      database: `${__dirname}../../target/db/sqlite-dev-db.sql`,
      logging: true,
    };
  }

  return {
    synchronize: process.env.BACKEND_ENV === 'test',
    migrationsRun: true,
    entities: [
      User,
      Authority,
      Breed,
      Person,
      Enclosure,
      HousingAssignment,
      IntakeRecord,
      Pet,
      PetStatusChange,
      VaccinationRecord,
      MedicalCondition,
      VetVisit,
      Treatment,
      FeedingPlan,
      Photo,
      AdoptionApplication,
      Ownership,
      // jhipster-needle-add-entity-to-ormconfig-entities - JHipster will add code here, do not remove
    ],
    migrations: [
      CreateTables1570200270081,
      SeedUsersRoles1570200490072,
      // jhipster-needle-add-migration-to-ormconfig-migrations - JHipster will add code here, do not remove
    ],
    autoLoadEntities: true,
    ...ormconfig,
  };
}

export { ormConfig };
