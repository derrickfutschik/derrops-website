export interface Payload {
  id: number;
  username: string;
  authorities?: string[];
}
