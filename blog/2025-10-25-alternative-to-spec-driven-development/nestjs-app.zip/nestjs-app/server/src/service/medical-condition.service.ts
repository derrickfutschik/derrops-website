import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { MedicalCondition } from '../domain/medical-condition.entity';
import { MedicalConditionDTO } from '../service/dto/medical-condition.dto';
import { MedicalConditionMapper } from '../service/mapper/medical-condition.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class MedicalConditionService {
  logger = new Logger('MedicalConditionService');

  constructor(@InjectRepository(MedicalCondition) private medicalConditionRepository: Repository<MedicalCondition>) {}

  async findById(id: number): Promise<MedicalConditionDTO | undefined> {
    const result = await this.medicalConditionRepository.findOne({
      relations,
      where: { id },
    });
    return MedicalConditionMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<MedicalConditionDTO>): Promise<MedicalConditionDTO | undefined> {
    const result = await this.medicalConditionRepository.findOne(options);
    return MedicalConditionMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<MedicalConditionDTO>): Promise<[MedicalConditionDTO[], number]> {
    const resultList = await this.medicalConditionRepository.findAndCount({ ...options, relations });
    const medicalConditionDTO: MedicalConditionDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(medicalCondition => medicalConditionDTO.push(MedicalConditionMapper.fromEntityToDTO(medicalCondition)));
      resultList[0] = medicalConditionDTO;
    }
    return resultList;
  }

  async save(medicalConditionDTO: MedicalConditionDTO, creator?: string): Promise<MedicalConditionDTO | undefined> {
    const entity = MedicalConditionMapper.fromDTOtoEntity(medicalConditionDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.medicalConditionRepository.save(entity);
    return MedicalConditionMapper.fromEntityToDTO(result);
  }

  async update(medicalConditionDTO: MedicalConditionDTO, updater?: string): Promise<MedicalConditionDTO | undefined> {
    const entity = MedicalConditionMapper.fromDTOtoEntity(medicalConditionDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.medicalConditionRepository.save(entity);
    return MedicalConditionMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.medicalConditionRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
