import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { PetStatusChange } from '../domain/pet-status-change.entity';
import { PetStatusChangeDTO } from '../service/dto/pet-status-change.dto';
import { PetStatusChangeMapper } from '../service/mapper/pet-status-change.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class PetStatusChangeService {
  logger = new Logger('PetStatusChangeService');

  constructor(@InjectRepository(PetStatusChange) private petStatusChangeRepository: Repository<PetStatusChange>) {}

  async findById(id: number): Promise<PetStatusChangeDTO | undefined> {
    const result = await this.petStatusChangeRepository.findOne({
      relations,
      where: { id },
    });
    return PetStatusChangeMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<PetStatusChangeDTO>): Promise<PetStatusChangeDTO | undefined> {
    const result = await this.petStatusChangeRepository.findOne(options);
    return PetStatusChangeMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<PetStatusChangeDTO>): Promise<[PetStatusChangeDTO[], number]> {
    const resultList = await this.petStatusChangeRepository.findAndCount({ ...options, relations });
    const petStatusChangeDTO: PetStatusChangeDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(petStatusChange => petStatusChangeDTO.push(PetStatusChangeMapper.fromEntityToDTO(petStatusChange)));
      resultList[0] = petStatusChangeDTO;
    }
    return resultList;
  }

  async save(petStatusChangeDTO: PetStatusChangeDTO, creator?: string): Promise<PetStatusChangeDTO | undefined> {
    const entity = PetStatusChangeMapper.fromDTOtoEntity(petStatusChangeDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.petStatusChangeRepository.save(entity);
    return PetStatusChangeMapper.fromEntityToDTO(result);
  }

  async update(petStatusChangeDTO: PetStatusChangeDTO, updater?: string): Promise<PetStatusChangeDTO | undefined> {
    const entity = PetStatusChangeMapper.fromDTOtoEntity(petStatusChangeDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.petStatusChangeRepository.save(entity);
    return PetStatusChangeMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.petStatusChangeRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
