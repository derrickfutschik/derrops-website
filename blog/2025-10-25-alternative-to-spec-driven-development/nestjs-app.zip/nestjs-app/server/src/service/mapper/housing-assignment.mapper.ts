import { HousingAssignment } from '../../domain/housing-assignment.entity';
import { HousingAssignmentDTO } from '../dto/housing-assignment.dto';

/**
 * A HousingAssignment mapper object.
 */
export class HousingAssignmentMapper {
  static fromDTOtoEntity(entityDTO: HousingAssignmentDTO): HousingAssignment {
    if (!entityDTO) {
      return;
    }
    const entity = new HousingAssignment();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: HousingAssignment): HousingAssignmentDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new HousingAssignmentDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
