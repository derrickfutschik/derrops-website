import { Treatment } from '../../domain/treatment.entity';
import { TreatmentDTO } from '../dto/treatment.dto';

/**
 * A Treatment mapper object.
 */
export class TreatmentMapper {
  static fromDTOtoEntity(entityDTO: TreatmentDTO): Treatment {
    if (!entityDTO) {
      return;
    }
    const entity = new Treatment();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: Treatment): TreatmentDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new TreatmentDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
