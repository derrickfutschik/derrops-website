import { Enclosure } from '../../domain/enclosure.entity';
import { EnclosureDTO } from '../dto/enclosure.dto';

/**
 * A Enclosure mapper object.
 */
export class EnclosureMapper {
  static fromDTOtoEntity(entityDTO: EnclosureDTO): Enclosure {
    if (!entityDTO) {
      return;
    }
    const entity = new Enclosure();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: Enclosure): EnclosureDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new EnclosureDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
