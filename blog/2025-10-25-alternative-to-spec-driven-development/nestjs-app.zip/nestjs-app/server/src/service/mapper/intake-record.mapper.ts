import { IntakeRecord } from '../../domain/intake-record.entity';
import { IntakeRecordDTO } from '../dto/intake-record.dto';

/**
 * A IntakeRecord mapper object.
 */
export class IntakeRecordMapper {
  static fromDTOtoEntity(entityDTO: IntakeRecordDTO): IntakeRecord {
    if (!entityDTO) {
      return;
    }
    const entity = new IntakeRecord();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: IntakeRecord): IntakeRecordDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new IntakeRecordDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
