import { VaccinationRecord } from '../../domain/vaccination-record.entity';
import { VaccinationRecordDTO } from '../dto/vaccination-record.dto';

/**
 * A VaccinationRecord mapper object.
 */
export class VaccinationRecordMapper {
  static fromDTOtoEntity(entityDTO: VaccinationRecordDTO): VaccinationRecord {
    if (!entityDTO) {
      return;
    }
    const entity = new VaccinationRecord();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: VaccinationRecord): VaccinationRecordDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new VaccinationRecordDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
