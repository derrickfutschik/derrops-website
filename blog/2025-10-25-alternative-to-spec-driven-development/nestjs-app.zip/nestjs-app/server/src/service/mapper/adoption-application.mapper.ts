import { AdoptionApplication } from '../../domain/adoption-application.entity';
import { AdoptionApplicationDTO } from '../dto/adoption-application.dto';

/**
 * A AdoptionApplication mapper object.
 */
export class AdoptionApplicationMapper {
  static fromDTOtoEntity(entityDTO: AdoptionApplicationDTO): AdoptionApplication {
    if (!entityDTO) {
      return;
    }
    const entity = new AdoptionApplication();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: AdoptionApplication): AdoptionApplicationDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new AdoptionApplicationDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
