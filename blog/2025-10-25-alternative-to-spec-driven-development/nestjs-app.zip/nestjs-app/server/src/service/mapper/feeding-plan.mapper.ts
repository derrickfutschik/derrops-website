import { FeedingPlan } from '../../domain/feeding-plan.entity';
import { FeedingPlanDTO } from '../dto/feeding-plan.dto';

/**
 * A FeedingPlan mapper object.
 */
export class FeedingPlanMapper {
  static fromDTOtoEntity(entityDTO: FeedingPlanDTO): FeedingPlan {
    if (!entityDTO) {
      return;
    }
    const entity = new FeedingPlan();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: FeedingPlan): FeedingPlanDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new FeedingPlanDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
