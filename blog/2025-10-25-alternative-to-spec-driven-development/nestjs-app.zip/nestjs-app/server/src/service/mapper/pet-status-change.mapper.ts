import { PetStatusChange } from '../../domain/pet-status-change.entity';
import { PetStatusChangeDTO } from '../dto/pet-status-change.dto';

/**
 * A PetStatusChange mapper object.
 */
export class PetStatusChangeMapper {
  static fromDTOtoEntity(entityDTO: PetStatusChangeDTO): PetStatusChange {
    if (!entityDTO) {
      return;
    }
    const entity = new PetStatusChange();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: PetStatusChange): PetStatusChangeDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new PetStatusChangeDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
