import { Ownership } from '../../domain/ownership.entity';
import { OwnershipDTO } from '../dto/ownership.dto';

/**
 * A Ownership mapper object.
 */
export class OwnershipMapper {
  static fromDTOtoEntity(entityDTO: OwnershipDTO): Ownership {
    if (!entityDTO) {
      return;
    }
    const entity = new Ownership();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: Ownership): OwnershipDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new OwnershipDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
