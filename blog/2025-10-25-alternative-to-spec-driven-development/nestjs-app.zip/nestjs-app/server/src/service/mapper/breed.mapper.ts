import { Breed } from '../../domain/breed.entity';
import { BreedDTO } from '../dto/breed.dto';

/**
 * A Breed mapper object.
 */
export class BreedMapper {
  static fromDTOtoEntity(entityDTO: BreedDTO): Breed {
    if (!entityDTO) {
      return;
    }
    const entity = new Breed();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: Breed): BreedDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new BreedDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
