import { VetVisit } from '../../domain/vet-visit.entity';
import { VetVisitDTO } from '../dto/vet-visit.dto';

/**
 * A VetVisit mapper object.
 */
export class VetVisitMapper {
  static fromDTOtoEntity(entityDTO: VetVisitDTO): VetVisit {
    if (!entityDTO) {
      return;
    }
    const entity = new VetVisit();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: VetVisit): VetVisitDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new VetVisitDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
