import { MedicalCondition } from '../../domain/medical-condition.entity';
import { MedicalConditionDTO } from '../dto/medical-condition.dto';

/**
 * A MedicalCondition mapper object.
 */
export class MedicalConditionMapper {
  static fromDTOtoEntity(entityDTO: MedicalConditionDTO): MedicalCondition {
    if (!entityDTO) {
      return;
    }
    const entity = new MedicalCondition();
    const fields = Object.getOwnPropertyNames(entityDTO);
    fields.forEach(field => {
      entity[field] = entityDTO[field];
    });
    return entity;
  }

  static fromEntityToDTO(entity: MedicalCondition): MedicalConditionDTO {
    if (!entity) {
      return;
    }
    const entityDTO = new MedicalConditionDTO();

    const fields = Object.getOwnPropertyNames(entity);

    fields.forEach(field => {
      entityDTO[field] = entity[field];
    });

    return entityDTO;
  }
}
