import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { IntakeRecord } from '../domain/intake-record.entity';
import { IntakeRecordDTO } from '../service/dto/intake-record.dto';
import { IntakeRecordMapper } from '../service/mapper/intake-record.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class IntakeRecordService {
  logger = new Logger('IntakeRecordService');

  constructor(@InjectRepository(IntakeRecord) private intakeRecordRepository: Repository<IntakeRecord>) {}

  async findById(id: number): Promise<IntakeRecordDTO | undefined> {
    const result = await this.intakeRecordRepository.findOne({
      relations,
      where: { id },
    });
    return IntakeRecordMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<IntakeRecordDTO>): Promise<IntakeRecordDTO | undefined> {
    const result = await this.intakeRecordRepository.findOne(options);
    return IntakeRecordMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<IntakeRecordDTO>): Promise<[IntakeRecordDTO[], number]> {
    const resultList = await this.intakeRecordRepository.findAndCount({ ...options, relations });
    const intakeRecordDTO: IntakeRecordDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(intakeRecord => intakeRecordDTO.push(IntakeRecordMapper.fromEntityToDTO(intakeRecord)));
      resultList[0] = intakeRecordDTO;
    }
    return resultList;
  }

  async save(intakeRecordDTO: IntakeRecordDTO, creator?: string): Promise<IntakeRecordDTO | undefined> {
    const entity = IntakeRecordMapper.fromDTOtoEntity(intakeRecordDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.intakeRecordRepository.save(entity);
    return IntakeRecordMapper.fromEntityToDTO(result);
  }

  async update(intakeRecordDTO: IntakeRecordDTO, updater?: string): Promise<IntakeRecordDTO | undefined> {
    const entity = IntakeRecordMapper.fromDTOtoEntity(intakeRecordDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.intakeRecordRepository.save(entity);
    return IntakeRecordMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.intakeRecordRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
