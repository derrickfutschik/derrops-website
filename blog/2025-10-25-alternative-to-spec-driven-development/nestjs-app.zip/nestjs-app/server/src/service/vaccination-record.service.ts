import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { VaccinationRecord } from '../domain/vaccination-record.entity';
import { VaccinationRecordDTO } from '../service/dto/vaccination-record.dto';
import { VaccinationRecordMapper } from '../service/mapper/vaccination-record.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class VaccinationRecordService {
  logger = new Logger('VaccinationRecordService');

  constructor(@InjectRepository(VaccinationRecord) private vaccinationRecordRepository: Repository<VaccinationRecord>) {}

  async findById(id: number): Promise<VaccinationRecordDTO | undefined> {
    const result = await this.vaccinationRecordRepository.findOne({
      relations,
      where: { id },
    });
    return VaccinationRecordMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<VaccinationRecordDTO>): Promise<VaccinationRecordDTO | undefined> {
    const result = await this.vaccinationRecordRepository.findOne(options);
    return VaccinationRecordMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<VaccinationRecordDTO>): Promise<[VaccinationRecordDTO[], number]> {
    const resultList = await this.vaccinationRecordRepository.findAndCount({ ...options, relations });
    const vaccinationRecordDTO: VaccinationRecordDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(vaccinationRecord => vaccinationRecordDTO.push(VaccinationRecordMapper.fromEntityToDTO(vaccinationRecord)));
      resultList[0] = vaccinationRecordDTO;
    }
    return resultList;
  }

  async save(vaccinationRecordDTO: VaccinationRecordDTO, creator?: string): Promise<VaccinationRecordDTO | undefined> {
    const entity = VaccinationRecordMapper.fromDTOtoEntity(vaccinationRecordDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.vaccinationRecordRepository.save(entity);
    return VaccinationRecordMapper.fromEntityToDTO(result);
  }

  async update(vaccinationRecordDTO: VaccinationRecordDTO, updater?: string): Promise<VaccinationRecordDTO | undefined> {
    const entity = VaccinationRecordMapper.fromDTOtoEntity(vaccinationRecordDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.vaccinationRecordRepository.save(entity);
    return VaccinationRecordMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.vaccinationRecordRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
