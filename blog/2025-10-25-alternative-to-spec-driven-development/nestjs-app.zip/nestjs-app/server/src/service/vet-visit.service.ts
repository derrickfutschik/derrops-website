import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { VetVisit } from '../domain/vet-visit.entity';
import { VetVisitDTO } from '../service/dto/vet-visit.dto';
import { VetVisitMapper } from '../service/mapper/vet-visit.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class VetVisitService {
  logger = new Logger('VetVisitService');

  constructor(@InjectRepository(VetVisit) private vetVisitRepository: Repository<VetVisit>) {}

  async findById(id: number): Promise<VetVisitDTO | undefined> {
    const result = await this.vetVisitRepository.findOne({
      relations,
      where: { id },
    });
    return VetVisitMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<VetVisitDTO>): Promise<VetVisitDTO | undefined> {
    const result = await this.vetVisitRepository.findOne(options);
    return VetVisitMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<VetVisitDTO>): Promise<[VetVisitDTO[], number]> {
    const resultList = await this.vetVisitRepository.findAndCount({ ...options, relations });
    const vetVisitDTO: VetVisitDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(vetVisit => vetVisitDTO.push(VetVisitMapper.fromEntityToDTO(vetVisit)));
      resultList[0] = vetVisitDTO;
    }
    return resultList;
  }

  async save(vetVisitDTO: VetVisitDTO, creator?: string): Promise<VetVisitDTO | undefined> {
    const entity = VetVisitMapper.fromDTOtoEntity(vetVisitDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.vetVisitRepository.save(entity);
    return VetVisitMapper.fromEntityToDTO(result);
  }

  async update(vetVisitDTO: VetVisitDTO, updater?: string): Promise<VetVisitDTO | undefined> {
    const entity = VetVisitMapper.fromDTOtoEntity(vetVisitDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.vetVisitRepository.save(entity);
    return VetVisitMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.vetVisitRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
