import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { Pet } from '../domain/pet.entity';
import { PetDTO } from '../service/dto/pet.dto';
import { PetMapper } from '../service/mapper/pet.mapper';

const relations = {
  breed: true,
  enclosure: true,
} as const;

@Injectable()
export class PetService {
  logger = new Logger('PetService');

  constructor(@InjectRepository(Pet) private petRepository: Repository<Pet>) {}

  async findById(id: number): Promise<PetDTO | undefined> {
    const result = await this.petRepository.findOne({
      relations,
      where: { id },
    });
    return PetMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<PetDTO>): Promise<PetDTO | undefined> {
    const result = await this.petRepository.findOne(options);
    return PetMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<PetDTO>): Promise<[PetDTO[], number]> {
    const resultList = await this.petRepository.findAndCount({ ...options, relations });
    const petDTO: PetDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(pet => petDTO.push(PetMapper.fromEntityToDTO(pet)));
      resultList[0] = petDTO;
    }
    return resultList;
  }

  async save(petDTO: PetDTO, creator?: string): Promise<PetDTO | undefined> {
    const entity = PetMapper.fromDTOtoEntity(petDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.petRepository.save(entity);
    return PetMapper.fromEntityToDTO(result);
  }

  async update(petDTO: PetDTO, updater?: string): Promise<PetDTO | undefined> {
    const entity = PetMapper.fromDTOtoEntity(petDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.petRepository.save(entity);
    return PetMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.petRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
