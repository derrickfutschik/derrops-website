import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { AdoptionApplication } from '../domain/adoption-application.entity';
import { AdoptionApplicationDTO } from '../service/dto/adoption-application.dto';
import { AdoptionApplicationMapper } from '../service/mapper/adoption-application.mapper';

const relations = {
  applicant: true,
  pet: true,
} as const;

@Injectable()
export class AdoptionApplicationService {
  logger = new Logger('AdoptionApplicationService');

  constructor(@InjectRepository(AdoptionApplication) private adoptionApplicationRepository: Repository<AdoptionApplication>) {}

  async findById(id: number): Promise<AdoptionApplicationDTO | undefined> {
    const result = await this.adoptionApplicationRepository.findOne({
      relations,
      where: { id },
    });
    return AdoptionApplicationMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<AdoptionApplicationDTO>): Promise<AdoptionApplicationDTO | undefined> {
    const result = await this.adoptionApplicationRepository.findOne(options);
    return AdoptionApplicationMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<AdoptionApplicationDTO>): Promise<[AdoptionApplicationDTO[], number]> {
    const resultList = await this.adoptionApplicationRepository.findAndCount({ ...options, relations });
    const adoptionApplicationDTO: AdoptionApplicationDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(adoptionApplication =>
        adoptionApplicationDTO.push(AdoptionApplicationMapper.fromEntityToDTO(adoptionApplication)),
      );
      resultList[0] = adoptionApplicationDTO;
    }
    return resultList;
  }

  async save(adoptionApplicationDTO: AdoptionApplicationDTO, creator?: string): Promise<AdoptionApplicationDTO | undefined> {
    const entity = AdoptionApplicationMapper.fromDTOtoEntity(adoptionApplicationDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.adoptionApplicationRepository.save(entity);
    return AdoptionApplicationMapper.fromEntityToDTO(result);
  }

  async update(adoptionApplicationDTO: AdoptionApplicationDTO, updater?: string): Promise<AdoptionApplicationDTO | undefined> {
    const entity = AdoptionApplicationMapper.fromDTOtoEntity(adoptionApplicationDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.adoptionApplicationRepository.save(entity);
    return AdoptionApplicationMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.adoptionApplicationRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
