import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { Photo } from '../domain/photo.entity';
import { PhotoDTO } from '../service/dto/photo.dto';
import { PhotoMapper } from '../service/mapper/photo.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class PhotoService {
  logger = new Logger('PhotoService');

  constructor(@InjectRepository(Photo) private photoRepository: Repository<Photo>) {}

  async findById(id: number): Promise<PhotoDTO | undefined> {
    const result = await this.photoRepository.findOne({
      relations,
      where: { id },
    });
    return PhotoMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<PhotoDTO>): Promise<PhotoDTO | undefined> {
    const result = await this.photoRepository.findOne(options);
    return PhotoMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<PhotoDTO>): Promise<[PhotoDTO[], number]> {
    const resultList = await this.photoRepository.findAndCount({ ...options, relations });
    const photoDTO: PhotoDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(photo => photoDTO.push(PhotoMapper.fromEntityToDTO(photo)));
      resultList[0] = photoDTO;
    }
    return resultList;
  }

  async save(photoDTO: PhotoDTO, creator?: string): Promise<PhotoDTO | undefined> {
    const entity = PhotoMapper.fromDTOtoEntity(photoDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.photoRepository.save(entity);
    return PhotoMapper.fromEntityToDTO(result);
  }

  async update(photoDTO: PhotoDTO, updater?: string): Promise<PhotoDTO | undefined> {
    const entity = PhotoMapper.fromDTOtoEntity(photoDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.photoRepository.save(entity);
    return PhotoMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.photoRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
