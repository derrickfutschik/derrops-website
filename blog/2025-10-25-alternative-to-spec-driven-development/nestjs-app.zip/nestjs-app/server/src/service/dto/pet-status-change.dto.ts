/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MaxLength } from 'class-validator';
import { PetStatus } from '../../domain/enumeration/pet-status';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A PetStatusChangeDTO object.
 */
export class PetStatusChangeDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ enum: PetStatus, description: 'fromStatus enum field' })
  fromStatus: PetStatus;

  @IsNotEmpty()
  @ApiProperty({ enum: PetStatus, description: 'toStatus enum field' })
  toStatus: PetStatus;

  @IsNotEmpty()
  @ApiProperty({ description: 'changedAt field' })
  changedAt: any;

  @MaxLength(200)
  @ApiProperty({ description: 'reason field', required: false })
  reason?: string;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
