/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length, Matches, Max, MaxLength, Min } from 'class-validator';
import { SpeciesType } from '../../domain/enumeration/species-type';
import { Sex } from '../../domain/enumeration/sex';
import { PetStatus } from '../../domain/enumeration/pet-status';
import { Temperament } from '../../domain/enumeration/temperament';
import { BaseDTO } from './base.dto';

import { BreedDTO } from './breed.dto';
import { EnclosureDTO } from './enclosure.dto';
import { IntakeRecordDTO } from './intake-record.dto';

/**
 * A PetDTO object.
 */
export class PetDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @Length(1, 60)
  @ApiProperty({ description: 'name field' })
  name: string;

  @IsNotEmpty()
  @ApiProperty({ enum: SpeciesType, description: 'species enum field' })
  species: SpeciesType;

  @IsNotEmpty()
  @ApiProperty({ enum: Sex, description: 'sex enum field' })
  sex: Sex;

  @ApiProperty({ description: 'dateOfBirth field', required: false })
  dateOfBirth?: any;

  @Min(0)
  @Max(3600)
  @ApiProperty({ description: 'estimatedAgeMonths field', required: false })
  estimatedAgeMonths?: number;

  @MaxLength(60)
  @ApiProperty({ description: 'color field', required: false })
  color?: string;

  @MaxLength(25)
  @Matches('^[A-Za-z0-9\\-]{5,25}$')
  @ApiProperty({ description: 'microchipNumber field', required: false })
  microchipNumber?: string;

  @IsNotEmpty()
  @ApiProperty({ description: 'intakeDate field' })
  intakeDate: any;

  @IsNotEmpty()
  @ApiProperty({ enum: PetStatus, description: 'status enum field' })
  status: PetStatus;

  @IsNotEmpty()
  @ApiProperty({ description: 'neutered field' })
  neutered: boolean;

  @Min(0)
  @Max(200)
  @ApiProperty({ description: 'weightKg field', required: false })
  weightKg?: number;

  @ApiProperty({ enum: Temperament, description: 'temperament enum field', required: false })
  temperament?: Temperament;

  @MaxLength(5000)
  @ApiProperty({ description: 'description field', required: false })
  description?: string;

  @ApiProperty({ type: () => BreedDTO, description: 'breed relationship' })
  breed?: BreedDTO;
  @ApiProperty({ type: () => EnclosureDTO, description: 'enclosure relationship' })
  enclosure?: EnclosureDTO;
  @ApiProperty({ type: () => IntakeRecordDTO, description: 'intake relationship' })
  intake?: IntakeRecordDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
