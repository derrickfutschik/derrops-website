/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length, Matches, MaxLength } from 'class-validator';
import { BaseDTO } from './base.dto';

/**
 * A PersonDTO object.
 */
export class PersonDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @Length(1, 60)
  @ApiProperty({ description: 'firstName field' })
  firstName: string;

  @IsNotEmpty()
  @Length(1, 60)
  @ApiProperty({ description: 'lastName field' })
  lastName: string;

  @MaxLength(32)
  @ApiProperty({ description: 'phone field', required: false })
  phone?: string;

  @MaxLength(120)
  @Matches('^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$')
  @ApiProperty({ description: 'email field', required: false })
  email?: string;

  @MaxLength(120)
  @ApiProperty({ description: 'street field', required: false })
  street?: string;

  @MaxLength(80)
  @ApiProperty({ description: 'city field', required: false })
  city?: string;

  @MaxLength(80)
  @ApiProperty({ description: 'state field', required: false })
  state?: string;

  @MaxLength(16)
  @ApiProperty({ description: 'postalCode field', required: false })
  postalCode?: string;

  @MaxLength(80)
  @ApiProperty({ description: 'country field', required: false })
  country?: string;

  @ApiProperty({ description: 'verified field', required: false })
  verified?: boolean;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
