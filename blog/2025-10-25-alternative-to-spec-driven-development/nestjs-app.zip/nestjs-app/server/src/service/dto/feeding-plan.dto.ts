/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Max, MaxLength, Min } from 'class-validator';
import { DietType } from '../../domain/enumeration/diet-type';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A FeedingPlanDTO object.
 */
export class FeedingPlanDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ enum: DietType, description: 'diet enum field' })
  diet: DietType;

  @MaxLength(80)
  @ApiProperty({ description: 'foodBrand field', required: false })
  foodBrand?: string;

  @Min(0)
  @Max(5000)
  @ApiProperty({ description: 'amountGrams field', required: false })
  amountGrams?: number;

  @Min(1)
  @Max(6)
  @ApiProperty({ description: 'frequencyPerDay field', required: false })
  frequencyPerDay?: number;

  @MaxLength(5000)
  @ApiProperty({ description: 'specialInstructions field', required: false })
  specialInstructions?: string;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
