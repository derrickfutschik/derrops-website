/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MaxLength } from 'class-validator';
import { ApplicationStatus } from '../../domain/enumeration/application-status';
import { BaseDTO } from './base.dto';

import { PersonDTO } from './person.dto';
import { PetDTO } from './pet.dto';

/**
 * A AdoptionApplicationDTO object.
 */
export class AdoptionApplicationDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ description: 'submittedDate field' })
  submittedDate: any;

  @IsNotEmpty()
  @ApiProperty({ enum: ApplicationStatus, description: 'status enum field' })
  status: ApplicationStatus;

  @MaxLength(5000)
  @ApiProperty({ description: 'notes field', required: false })
  notes?: string;

  @ApiProperty({ type: () => PersonDTO, description: 'applicant relationship' })
  applicant?: PersonDTO;
  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
