/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';
import { EnclosureDTO } from './enclosure.dto';

/**
 * A HousingAssignmentDTO object.
 */
export class HousingAssignmentDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ description: 'startDate field' })
  startDate: any;

  @ApiProperty({ description: 'endDate field', required: false })
  endDate?: any;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;
  @ApiProperty({ type: () => EnclosureDTO, description: 'enclosure relationship' })
  enclosure?: EnclosureDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
