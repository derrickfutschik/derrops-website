/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { OwnershipType } from '../../domain/enumeration/ownership-type';
import { BaseDTO } from './base.dto';

import { PersonDTO } from './person.dto';
import { PetDTO } from './pet.dto';

/**
 * A OwnershipDTO object.
 */
export class OwnershipDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ enum: OwnershipType, description: 'type enum field' })
  type: OwnershipType;

  @IsNotEmpty()
  @ApiProperty({ description: 'startDate field' })
  startDate: any;

  @ApiProperty({ description: 'endDate field', required: false })
  endDate?: any;

  @ApiProperty({ type: () => PersonDTO, description: 'owner relationship' })
  owner?: PersonDTO;
  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
