/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MaxLength } from 'class-validator';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A VetVisitDTO object.
 */
export class VetVisitDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ description: 'visitDate field' })
  visitDate: any;

  @MaxLength(120)
  @ApiProperty({ description: 'clinicName field', required: false })
  clinicName?: string;

  @MaxLength(80)
  @ApiProperty({ description: 'vetName field', required: false })
  vetName?: string;

  @MaxLength(160)
  @ApiProperty({ description: 'reason field', required: false })
  reason?: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'report field', required: false })
  report?: string;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
