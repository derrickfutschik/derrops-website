/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MaxLength } from 'class-validator';
import { Vaccine } from '../../domain/enumeration/vaccine';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A VaccinationRecordDTO object.
 */
export class VaccinationRecordDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ enum: Vaccine, description: 'vaccine enum field' })
  vaccine: Vaccine;

  @IsNotEmpty()
  @ApiProperty({ description: 'dateGiven field' })
  dateGiven: any;

  @ApiProperty({ description: 'dueDate field', required: false })
  dueDate?: any;

  @MaxLength(80)
  @ApiProperty({ description: 'administeredBy field', required: false })
  administeredBy?: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'notes field', required: false })
  notes?: string;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
