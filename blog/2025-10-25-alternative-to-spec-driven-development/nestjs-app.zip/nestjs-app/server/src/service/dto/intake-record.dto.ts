/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MaxLength } from 'class-validator';
import { IntakeSource } from '../../domain/enumeration/intake-source';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A IntakeRecordDTO object.
 */
export class IntakeRecordDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ description: 'intakeDate field' })
  intakeDate: any;

  @IsNotEmpty()
  @ApiProperty({ enum: IntakeSource, description: 'source enum field' })
  source: IntakeSource;

  @MaxLength(160)
  @ApiProperty({ description: 'foundLocation field', required: false })
  foundLocation?: string;

  @MaxLength(200)
  @ApiProperty({ description: 'surrenderedReason field', required: false })
  surrenderedReason?: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'initialHealthNotes field', required: false })
  initialHealthNotes?: string;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
