/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length, MaxLength } from 'class-validator';
import { SpeciesType } from '../../domain/enumeration/species-type';
import { BaseDTO } from './base.dto';

/**
 * A BreedDTO object.
 */
export class BreedDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @Length(2, 80)
  @ApiProperty({ description: 'name field' })
  name: string;

  @IsNotEmpty()
  @ApiProperty({ enum: SpeciesType, description: 'species enum field' })
  species: SpeciesType;

  @MaxLength(32)
  @ApiProperty({ description: 'sizeLabel field', required: false })
  sizeLabel?: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'notes field', required: false })
  notes?: string;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
