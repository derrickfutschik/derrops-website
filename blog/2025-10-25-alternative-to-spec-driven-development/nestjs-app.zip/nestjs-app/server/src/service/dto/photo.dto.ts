/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { MaxLength } from 'class-validator';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A PhotoDTO object.
 */
export class PhotoDTO extends BaseDTO {
  id?: number;

  @ApiProperty({ description: 'imageData field' })
  imageData: any;

  imageDataContentType: string;
  @MaxLength(140)
  @ApiProperty({ description: 'caption field', required: false })
  caption?: string;

  @ApiProperty({ description: 'takenAt field', required: false })
  takenAt?: any;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
