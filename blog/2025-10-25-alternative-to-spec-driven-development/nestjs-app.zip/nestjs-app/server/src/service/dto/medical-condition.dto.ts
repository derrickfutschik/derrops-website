/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length, MaxLength } from 'class-validator';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';

/**
 * A MedicalConditionDTO object.
 */
export class MedicalConditionDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @Length(2, 80)
  @ApiProperty({ description: 'name field' })
  name: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'description field', required: false })
  description?: string;

  @ApiProperty({ description: 'chronic field', required: false })
  chronic?: boolean;

  @ApiProperty({ description: 'diagnosedDate field', required: false })
  diagnosedDate?: any;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
