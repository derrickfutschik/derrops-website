/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length, Max, MaxLength, Min } from 'class-validator';
import { EnclosureType } from '../../domain/enumeration/enclosure-type';
import { BaseDTO } from './base.dto';

/**
 * A EnclosureDTO object.
 */
export class EnclosureDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @Length(1, 30)
  @ApiProperty({ description: 'code field' })
  code: string;

  @IsNotEmpty()
  @ApiProperty({ enum: EnclosureType, description: 'type enum field' })
  type: EnclosureType;

  @IsNotEmpty()
  @Min(1)
  @Max(50)
  @ApiProperty({ description: 'capacity field' })
  capacity: number;

  @MaxLength(120)
  @ApiProperty({ description: 'location field', required: false })
  location?: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'notes field', required: false })
  notes?: string;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
