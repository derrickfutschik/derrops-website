/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Length, MaxLength } from 'class-validator';
import { TreatmentType } from '../../domain/enumeration/treatment-type';
import { BaseDTO } from './base.dto';

import { PetDTO } from './pet.dto';
import { MedicalConditionDTO } from './medical-condition.dto';

/**
 * A TreatmentDTO object.
 */
export class TreatmentDTO extends BaseDTO {
  id?: number;

  @IsNotEmpty()
  @ApiProperty({ enum: TreatmentType, description: 'type enum field' })
  type: TreatmentType;

  @IsNotEmpty()
  @Length(2, 80)
  @ApiProperty({ description: 'name field' })
  name: string;

  @ApiProperty({ description: 'startDate field', required: false })
  startDate?: any;

  @ApiProperty({ description: 'endDate field', required: false })
  endDate?: any;

  @MaxLength(80)
  @ApiProperty({ description: 'dosage field', required: false })
  dosage?: string;

  @MaxLength(5000)
  @ApiProperty({ description: 'instructions field', required: false })
  instructions?: string;

  @ApiProperty({ type: () => PetDTO, description: 'pet relationship' })
  pet?: PetDTO;
  @ApiProperty({ type: () => MedicalConditionDTO, description: 'condition relationship' })
  condition?: MedicalConditionDTO;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
