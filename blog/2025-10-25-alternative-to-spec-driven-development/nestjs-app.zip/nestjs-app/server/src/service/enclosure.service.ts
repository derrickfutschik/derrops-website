import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { Enclosure } from '../domain/enclosure.entity';
import { EnclosureDTO } from '../service/dto/enclosure.dto';
import { EnclosureMapper } from '../service/mapper/enclosure.mapper';

@Injectable()
export class EnclosureService {
  logger = new Logger('EnclosureService');

  constructor(@InjectRepository(Enclosure) private enclosureRepository: Repository<Enclosure>) {}

  async findById(id: number): Promise<EnclosureDTO | undefined> {
    const result = await this.enclosureRepository.findOne({
      where: { id },
    });
    return EnclosureMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<EnclosureDTO>): Promise<EnclosureDTO | undefined> {
    const result = await this.enclosureRepository.findOne(options);
    return EnclosureMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<EnclosureDTO>): Promise<[EnclosureDTO[], number]> {
    const resultList = await this.enclosureRepository.findAndCount(options);
    const enclosureDTO: EnclosureDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(enclosure => enclosureDTO.push(EnclosureMapper.fromEntityToDTO(enclosure)));
      resultList[0] = enclosureDTO;
    }
    return resultList;
  }

  async save(enclosureDTO: EnclosureDTO, creator?: string): Promise<EnclosureDTO | undefined> {
    const entity = EnclosureMapper.fromDTOtoEntity(enclosureDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.enclosureRepository.save(entity);
    return EnclosureMapper.fromEntityToDTO(result);
  }

  async update(enclosureDTO: EnclosureDTO, updater?: string): Promise<EnclosureDTO | undefined> {
    const entity = EnclosureMapper.fromDTOtoEntity(enclosureDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.enclosureRepository.save(entity);
    return EnclosureMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.enclosureRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
