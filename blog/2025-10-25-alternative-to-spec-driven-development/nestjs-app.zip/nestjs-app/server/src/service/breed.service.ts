import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { Breed } from '../domain/breed.entity';
import { BreedDTO } from '../service/dto/breed.dto';
import { BreedMapper } from '../service/mapper/breed.mapper';

@Injectable()
export class BreedService {
  logger = new Logger('BreedService');

  constructor(@InjectRepository(Breed) private breedRepository: Repository<Breed>) {}

  async findById(id: number): Promise<BreedDTO | undefined> {
    const result = await this.breedRepository.findOne({
      where: { id },
    });
    return BreedMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<BreedDTO>): Promise<BreedDTO | undefined> {
    const result = await this.breedRepository.findOne(options);
    return BreedMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<BreedDTO>): Promise<[BreedDTO[], number]> {
    const resultList = await this.breedRepository.findAndCount(options);
    const breedDTO: BreedDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(breed => breedDTO.push(BreedMapper.fromEntityToDTO(breed)));
      resultList[0] = breedDTO;
    }
    return resultList;
  }

  async save(breedDTO: BreedDTO, creator?: string): Promise<BreedDTO | undefined> {
    const entity = BreedMapper.fromDTOtoEntity(breedDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.breedRepository.save(entity);
    return BreedMapper.fromEntityToDTO(result);
  }

  async update(breedDTO: BreedDTO, updater?: string): Promise<BreedDTO | undefined> {
    const entity = BreedMapper.fromDTOtoEntity(breedDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.breedRepository.save(entity);
    return BreedMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.breedRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
