import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { Treatment } from '../domain/treatment.entity';
import { TreatmentDTO } from '../service/dto/treatment.dto';
import { TreatmentMapper } from '../service/mapper/treatment.mapper';

const relations = {
  pet: true,
  condition: true,
} as const;

@Injectable()
export class TreatmentService {
  logger = new Logger('TreatmentService');

  constructor(@InjectRepository(Treatment) private treatmentRepository: Repository<Treatment>) {}

  async findById(id: number): Promise<TreatmentDTO | undefined> {
    const result = await this.treatmentRepository.findOne({
      relations,
      where: { id },
    });
    return TreatmentMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<TreatmentDTO>): Promise<TreatmentDTO | undefined> {
    const result = await this.treatmentRepository.findOne(options);
    return TreatmentMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<TreatmentDTO>): Promise<[TreatmentDTO[], number]> {
    const resultList = await this.treatmentRepository.findAndCount({ ...options, relations });
    const treatmentDTO: TreatmentDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(treatment => treatmentDTO.push(TreatmentMapper.fromEntityToDTO(treatment)));
      resultList[0] = treatmentDTO;
    }
    return resultList;
  }

  async save(treatmentDTO: TreatmentDTO, creator?: string): Promise<TreatmentDTO | undefined> {
    const entity = TreatmentMapper.fromDTOtoEntity(treatmentDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.treatmentRepository.save(entity);
    return TreatmentMapper.fromEntityToDTO(result);
  }

  async update(treatmentDTO: TreatmentDTO, updater?: string): Promise<TreatmentDTO | undefined> {
    const entity = TreatmentMapper.fromDTOtoEntity(treatmentDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.treatmentRepository.save(entity);
    return TreatmentMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.treatmentRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
