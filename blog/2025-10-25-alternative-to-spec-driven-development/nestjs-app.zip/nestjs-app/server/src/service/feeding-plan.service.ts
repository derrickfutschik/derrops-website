import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyOptions, FindOneOptions, Repository } from 'typeorm';
import { FeedingPlan } from '../domain/feeding-plan.entity';
import { FeedingPlanDTO } from '../service/dto/feeding-plan.dto';
import { FeedingPlanMapper } from '../service/mapper/feeding-plan.mapper';

const relations = {
  pet: true,
} as const;

@Injectable()
export class FeedingPlanService {
  logger = new Logger('FeedingPlanService');

  constructor(@InjectRepository(FeedingPlan) private feedingPlanRepository: Repository<FeedingPlan>) {}

  async findById(id: number): Promise<FeedingPlanDTO | undefined> {
    const result = await this.feedingPlanRepository.findOne({
      relations,
      where: { id },
    });
    return FeedingPlanMapper.fromEntityToDTO(result);
  }

  async findByFields(options: FindOneOptions<FeedingPlanDTO>): Promise<FeedingPlanDTO | undefined> {
    const result = await this.feedingPlanRepository.findOne(options);
    return FeedingPlanMapper.fromEntityToDTO(result);
  }

  async findAndCount(options: FindManyOptions<FeedingPlanDTO>): Promise<[FeedingPlanDTO[], number]> {
    const resultList = await this.feedingPlanRepository.findAndCount({ ...options, relations });
    const feedingPlanDTO: FeedingPlanDTO[] = [];
    if (resultList && resultList[0]) {
      resultList[0].forEach(feedingPlan => feedingPlanDTO.push(FeedingPlanMapper.fromEntityToDTO(feedingPlan)));
      resultList[0] = feedingPlanDTO;
    }
    return resultList;
  }

  async save(feedingPlanDTO: FeedingPlanDTO, creator?: string): Promise<FeedingPlanDTO | undefined> {
    const entity = FeedingPlanMapper.fromDTOtoEntity(feedingPlanDTO);
    if (creator) {
      if (!entity.createdBy) {
        entity.createdBy = creator;
      }
      entity.lastModifiedBy = creator;
    }
    const result = await this.feedingPlanRepository.save(entity);
    return FeedingPlanMapper.fromEntityToDTO(result);
  }

  async update(feedingPlanDTO: FeedingPlanDTO, updater?: string): Promise<FeedingPlanDTO | undefined> {
    const entity = FeedingPlanMapper.fromDTOtoEntity(feedingPlanDTO);
    if (updater) {
      entity.lastModifiedBy = updater;
    }
    const result = await this.feedingPlanRepository.save(entity);
    return FeedingPlanMapper.fromEntityToDTO(result);
  }

  async deleteById(id: number): Promise<void | undefined> {
    await this.feedingPlanRepository.delete(id);
    const entityFind = await this.findById(id);
    if (entityFind) {
      throw new HttpException('Error, entity not deleted!', HttpStatus.NOT_FOUND);
    }
  }
}
