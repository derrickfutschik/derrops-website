/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';
import { Enclosure } from './enclosure.entity';

/**
 * A HousingAssignment.
 */
@Entity('housing_assignment')
export class HousingAssignment extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'date', name: 'start_date' })
  startDate: any;

  @Column({ type: 'date', name: 'end_date', nullable: true })
  endDate?: any;

  @ManyToOne(type => Pet)
  pet?: Pet;

  @ManyToOne(type => Enclosure)
  enclosure?: Enclosure;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
