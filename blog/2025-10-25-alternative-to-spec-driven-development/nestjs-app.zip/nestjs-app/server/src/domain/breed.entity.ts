/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { SpeciesType } from './enumeration/species-type';

/**
 * A Breed.
 */
@Entity('breed')
export class Breed extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ name: 'name', length: 80 })
  name: string;

  @Column({ type: 'varchar', name: 'species', enum: SpeciesType })
  species: SpeciesType;

  @Column({ name: 'size_label', length: 32, nullable: true })
  sizeLabel?: string;

  @Column({ name: 'notes', length: 5000, nullable: true })
  notes?: string;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
