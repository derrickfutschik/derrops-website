/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';
import { Vaccine } from './enumeration/vaccine';

/**
 * A VaccinationRecord.
 */
@Entity('vaccination_record')
export class VaccinationRecord extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'varchar', name: 'vaccine', enum: Vaccine })
  vaccine: Vaccine;

  @Column({ type: 'date', name: 'date_given' })
  dateGiven: any;

  @Column({ type: 'date', name: 'due_date', nullable: true })
  dueDate?: any;

  @Column({ name: 'administered_by', length: 80, nullable: true })
  administeredBy?: string;

  @Column({ name: 'notes', length: 5000, nullable: true })
  notes?: string;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
