export enum DietType {
  DRY_FOOD = 'DRY_FOOD',

  WET_FOOD = 'WET_FOOD',

  RAW = 'RAW',

  MIXED = 'MIXED',

  PRESCRIPTION = 'PRESCRIPTION',

  OTHER = 'OTHER',
}
