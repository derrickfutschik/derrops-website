export enum EnclosureType {
  KENNEL = 'KENNEL',

  CAGE = 'CAGE',

  ROOM = 'ROOM',

  PEN = 'PEN',

  AQUARIUM = 'AQUARIUM',

  TERRARIUM = 'TERRARIUM',

  OTHER = 'OTHER',
}
