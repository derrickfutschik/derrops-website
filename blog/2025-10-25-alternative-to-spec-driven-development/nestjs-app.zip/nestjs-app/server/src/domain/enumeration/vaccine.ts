export enum Vaccine {
  RABIES = 'RABIES',

  DISTEMPER = 'DISTEMPER',

  PARVO = 'PARVO',

  FELV = 'FELV',

  FVRCP = 'FVRCP',

  BORDETELLA = 'BORDETELLA',

  OTHER = 'OTHER',
}
