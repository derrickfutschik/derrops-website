export enum OwnershipType {
  ADOPTION = 'ADOPTION',

  FOSTER = 'FOSTER',

  TEMP_CARE = 'TEMP_CARE',
}
