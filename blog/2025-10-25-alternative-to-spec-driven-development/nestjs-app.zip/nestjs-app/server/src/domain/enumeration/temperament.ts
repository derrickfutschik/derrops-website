export enum Temperament {
  CALM = 'CALM',

  ACTIVE = 'ACTIVE',

  SHY = 'SHY',

  AGGRESSIVE = 'AGGRESSIVE',

  FRIENDLY = 'FRIENDLY',

  UNKNOWN = 'UNKNOWN',
}
