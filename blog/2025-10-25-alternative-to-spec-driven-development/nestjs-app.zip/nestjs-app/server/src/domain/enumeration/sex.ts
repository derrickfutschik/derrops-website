export enum Sex {
  MALE = 'MALE',

  FEMALE = 'FEMALE',

  UNKNOWN = 'UNKNOWN',
}
