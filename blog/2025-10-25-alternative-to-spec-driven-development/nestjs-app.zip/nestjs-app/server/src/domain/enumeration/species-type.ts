export enum SpeciesType {
  DOG = 'DOG',

  CAT = 'CAT',

  RABBIT = 'RABBIT',

  BIRD = 'BIRD',

  REPTILE = 'REPTILE',

  SMALL_MAMMAL = 'SMALL_MAMMAL',

  OTHER = 'OTHER',
}
