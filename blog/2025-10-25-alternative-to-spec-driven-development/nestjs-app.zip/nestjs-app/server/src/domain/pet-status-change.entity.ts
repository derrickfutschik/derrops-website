/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';
import { PetStatus } from './enumeration/pet-status';

/**
 * A PetStatusChange.
 */
@Entity('pet_status_change')
export class PetStatusChange extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'varchar', name: 'from_status', enum: PetStatus })
  fromStatus: PetStatus;

  @Column({ type: 'varchar', name: 'to_status', enum: PetStatus })
  toStatus: PetStatus;

  @Column({ type: 'datetime', name: 'changed_at' })
  changedAt: any;

  @Column({ name: 'reason', length: 200, nullable: true })
  reason?: string;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
