/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';

/**
 * A Photo.
 */
@Entity('photo')
export class Photo extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'blob', name: 'image_data' })
  imageData: any;

  @Column({ name: 'image_data_content_type' })
  imageDataContentType: string;

  @Column({ name: 'caption', length: 140, nullable: true })
  caption?: string;

  @Column({ type: 'datetime', name: 'taken_at', nullable: true })
  takenAt?: any;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
