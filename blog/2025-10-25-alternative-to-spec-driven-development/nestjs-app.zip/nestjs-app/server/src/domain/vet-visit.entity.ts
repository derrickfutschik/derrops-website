/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';

/**
 * A VetVisit.
 */
@Entity('vet_visit')
export class VetVisit extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'datetime', name: 'visit_date' })
  visitDate: any;

  @Column({ name: 'clinic_name', length: 120, nullable: true })
  clinicName?: string;

  @Column({ name: 'vet_name', length: 80, nullable: true })
  vetName?: string;

  @Column({ name: 'reason', length: 160, nullable: true })
  reason?: string;

  @Column({ name: 'report', length: 5000, nullable: true })
  report?: string;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
