/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Breed } from './breed.entity';
import { Enclosure } from './enclosure.entity';
import { IntakeRecord } from './intake-record.entity';
import { SpeciesType } from './enumeration/species-type';
import { Sex } from './enumeration/sex';
import { PetStatus } from './enumeration/pet-status';
import { Temperament } from './enumeration/temperament';

/**
 * A Pet.
 */
@Entity('pet')
export class Pet extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ name: 'name', length: 60 })
  name: string;

  @Column({ type: 'varchar', name: 'species', enum: SpeciesType })
  species: SpeciesType;

  @Column({ type: 'varchar', name: 'sex', enum: Sex })
  sex: Sex;

  @Column({ type: 'date', name: 'date_of_birth', nullable: true })
  dateOfBirth?: any;

  @Column({ type: 'integer', name: 'estimated_age_months', nullable: true })
  estimatedAgeMonths?: number;

  @Column({ name: 'color', length: 60, nullable: true })
  color?: string;

  @Column({ name: 'microchip_number', length: 25, nullable: true, unique: true })
  microchipNumber?: string;

  @Column({ type: 'date', name: 'intake_date' })
  intakeDate: any;

  @Column({ type: 'varchar', name: 'status', enum: PetStatus })
  status: PetStatus;

  @Column({ type: 'boolean', name: 'neutered' })
  neutered: boolean;

  @Column({ type: 'decimal', name: 'weight_kg', precision: 10, scale: 2, nullable: true })
  weightKg?: number;

  @Column({ type: 'varchar', name: 'temperament', enum: Temperament })
  temperament?: Temperament;

  @Column({ name: 'description', length: 5000, nullable: true })
  description?: string;

  @ManyToOne(type => Breed)
  breed?: Breed;

  @ManyToOne(type => Enclosure)
  enclosure?: Enclosure;

  @OneToOne(type => IntakeRecord)
  intake?: IntakeRecord;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
