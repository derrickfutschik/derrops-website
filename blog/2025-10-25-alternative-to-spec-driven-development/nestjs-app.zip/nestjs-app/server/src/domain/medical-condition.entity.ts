/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';

/**
 * A MedicalCondition.
 */
@Entity('medical_condition')
export class MedicalCondition extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ name: 'name', length: 80 })
  name: string;

  @Column({ name: 'description', length: 5000, nullable: true })
  description?: string;

  @Column({ type: 'boolean', name: 'chronic', nullable: true })
  chronic?: boolean;

  @Column({ type: 'date', name: 'diagnosed_date', nullable: true })
  diagnosedDate?: any;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
