/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Person } from './person.entity';
import { Pet } from './pet.entity';
import { ApplicationStatus } from './enumeration/application-status';

/**
 * A AdoptionApplication.
 */
@Entity('adoption_application')
export class AdoptionApplication extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'datetime', name: 'submitted_date' })
  submittedDate: any;

  @Column({ type: 'varchar', name: 'status', enum: ApplicationStatus })
  status: ApplicationStatus;

  @Column({ name: 'notes', length: 5000, nullable: true })
  notes?: string;

  @ManyToOne(type => Person)
  applicant?: Person;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
