/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';
import { IntakeSource } from './enumeration/intake-source';

/**
 * A IntakeRecord.
 */
@Entity('intake_record')
export class IntakeRecord extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'date', name: 'intake_date' })
  intakeDate: any;

  @Column({ type: 'varchar', name: 'source', enum: IntakeSource })
  source: IntakeSource;

  @Column({ name: 'found_location', length: 160, nullable: true })
  foundLocation?: string;

  @Column({ name: 'surrendered_reason', length: 200, nullable: true })
  surrenderedReason?: string;

  @Column({ name: 'initial_health_notes', length: 5000, nullable: true })
  initialHealthNotes?: string;

  @OneToOne(type => Pet)
  @JoinColumn()
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
