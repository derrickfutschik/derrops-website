/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';
import { MedicalCondition } from './medical-condition.entity';
import { TreatmentType } from './enumeration/treatment-type';

/**
 * A Treatment.
 */
@Entity('treatment')
export class Treatment extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'varchar', name: 'type', enum: TreatmentType })
  type: TreatmentType;

  @Column({ name: 'name', length: 80 })
  name: string;

  @Column({ type: 'date', name: 'start_date', nullable: true })
  startDate?: any;

  @Column({ type: 'date', name: 'end_date', nullable: true })
  endDate?: any;

  @Column({ name: 'dosage', length: 80, nullable: true })
  dosage?: string;

  @Column({ name: 'instructions', length: 5000, nullable: true })
  instructions?: string;

  @ManyToOne(type => Pet)
  pet?: Pet;

  @ManyToOne(type => MedicalCondition)
  condition?: MedicalCondition;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
