/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Person } from './person.entity';
import { Pet } from './pet.entity';
import { OwnershipType } from './enumeration/ownership-type';

/**
 * A Ownership.
 */
@Entity('ownership')
export class Ownership extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'varchar', name: 'type', enum: OwnershipType })
  type: OwnershipType;

  @Column({ type: 'date', name: 'start_date' })
  startDate: any;

  @Column({ type: 'date', name: 'end_date', nullable: true })
  endDate?: any;

  @ManyToOne(type => Person)
  owner?: Person;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
