/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

/**
 * A Person.
 */
@Entity('person')
export class Person extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ name: 'first_name', length: 60 })
  firstName: string;

  @Column({ name: 'last_name', length: 60 })
  lastName: string;

  @Column({ name: 'phone', length: 32, nullable: true })
  phone?: string;

  @Column({ name: 'email', length: 120, nullable: true })
  email?: string;

  @Column({ name: 'street', length: 120, nullable: true })
  street?: string;

  @Column({ name: 'city', length: 80, nullable: true })
  city?: string;

  @Column({ name: 'state', length: 80, nullable: true })
  state?: string;

  @Column({ name: 'postal_code', length: 16, nullable: true })
  postalCode?: string;

  @Column({ name: 'country', length: 80, nullable: true })
  country?: string;

  @Column({ type: 'boolean', name: 'verified', nullable: true })
  verified?: boolean;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
