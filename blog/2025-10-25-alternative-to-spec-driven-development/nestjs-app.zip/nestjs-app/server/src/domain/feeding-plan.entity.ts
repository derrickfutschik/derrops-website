/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { Pet } from './pet.entity';
import { DietType } from './enumeration/diet-type';

/**
 * A FeedingPlan.
 */
@Entity('feeding_plan')
export class FeedingPlan extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: 'varchar', name: 'diet', enum: DietType })
  diet: DietType;

  @Column({ name: 'food_brand', length: 80, nullable: true })
  foodBrand?: string;

  @Column({ type: 'integer', name: 'amount_grams', nullable: true })
  amountGrams?: number;

  @Column({ type: 'integer', name: 'frequency_per_day', nullable: true })
  frequencyPerDay?: number;

  @Column({ name: 'special_instructions', length: 5000, nullable: true })
  specialInstructions?: string;

  @ManyToOne(type => Pet)
  pet?: Pet;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
