/* eslint-disable @typescript-eslint/no-unused-vars */
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { BaseEntity } from './base/base.entity';

import { EnclosureType } from './enumeration/enclosure-type';

/**
 * A Enclosure.
 */
@Entity('enclosure')
export class Enclosure extends BaseEntity {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ name: 'code', length: 30, unique: true })
  code: string;

  @Column({ type: 'varchar', name: 'type', enum: EnclosureType })
  type: EnclosureType;

  @Column({ type: 'integer', name: 'capacity' })
  capacity: number;

  @Column({ name: 'location', length: 120, nullable: true })
  location?: string;

  @Column({ name: 'notes', length: 5000, nullable: true })
  notes?: string;

  // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
}
