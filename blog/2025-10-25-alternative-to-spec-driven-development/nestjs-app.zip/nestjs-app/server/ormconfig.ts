import { ormConfig } from './src/orm.config';

export default ormConfig();
