import { afterEach, beforeEach, describe, expect, it } from '@jest/globals';
import { Test, TestingModule } from '@nestjs/testing';
import request = require('supertest');
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { AuthGuard } from '../src/security/guards/auth.guard';
import { RolesGuard } from '../src/security/guards/roles.guard';
import { OwnershipDTO } from '../src/service/dto/ownership.dto';
import { OwnershipService } from '../src/service/ownership.service';

describe('Ownership Controller', () => {
  let app: INestApplication;

  const authGuardMock = { canActivate: (): any => true };
  const rolesGuardMock = { canActivate: (): any => true };
  const entityMock: any = {
    id: 'entityId',
  };

  const serviceMock = {
    findById: (): any => entityMock,
    findAndCount: (): any => [entityMock, 0],
    save: (): any => entityMock,
    update: (): any => entityMock,
    deleteById: (): any => entityMock,
  };

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideGuard(AuthGuard)
      .useValue(authGuardMock)
      .overrideGuard(RolesGuard)
      .useValue(rolesGuardMock)
      .overrideProvider(OwnershipService)
      .useValue(serviceMock)
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/GET all ownerships ', async () => {
    const getEntities: OwnershipDTO[] = (await request(app.getHttpServer()).get('/api/ownerships').expect(200)).body;

    expect(getEntities).toEqual(entityMock);
  });

  it('/GET ownerships by id', async () => {
    const getEntity: OwnershipDTO = (await request(app.getHttpServer()).get(`/api/ownerships/${entityMock.id}`).expect(200)).body;

    expect(getEntity).toEqual(entityMock);
  });

  it('/POST create ownerships', async () => {
    const createdEntity: OwnershipDTO = (await request(app.getHttpServer()).post('/api/ownerships').send(entityMock).expect(201)).body;

    expect(createdEntity).toEqual(entityMock);
  });

  it('/PUT update ownerships', async () => {
    const updatedEntity: OwnershipDTO = (await request(app.getHttpServer()).put('/api/ownerships').send(entityMock).expect(201)).body;

    expect(updatedEntity).toEqual(entityMock);
  });

  it('/PUT update ownerships from id', async () => {
    const updatedEntity: OwnershipDTO = (
      await request(app.getHttpServer()).put(`/api/ownerships/${entityMock.id}`).send(entityMock).expect(201)
    ).body;

    expect(updatedEntity).toEqual(entityMock);
  });

  it('/DELETE ownerships', async () => {
    const deletedEntity: OwnershipDTO = (await request(app.getHttpServer()).delete(`/api/ownerships/${entityMock.id}`).expect(204)).body;

    expect(deletedEntity).toEqual({});
  });

  afterEach(async () => {
    await app?.close();
  });
});
