import { afterEach, beforeEach, describe, expect, it } from '@jest/globals';
import { Test, TestingModule } from '@nestjs/testing';
import request = require('supertest');
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { AuthGuard } from '../src/security/guards/auth.guard';
import { RolesGuard } from '../src/security/guards/roles.guard';
import { HousingAssignmentDTO } from '../src/service/dto/housing-assignment.dto';
import { HousingAssignmentService } from '../src/service/housing-assignment.service';

describe('HousingAssignment Controller', () => {
  let app: INestApplication;

  const authGuardMock = { canActivate: (): any => true };
  const rolesGuardMock = { canActivate: (): any => true };
  const entityMock: any = {
    id: 'entityId',
  };

  const serviceMock = {
    findById: (): any => entityMock,
    findAndCount: (): any => [entityMock, 0],
    save: (): any => entityMock,
    update: (): any => entityMock,
    deleteById: (): any => entityMock,
  };

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideGuard(AuthGuard)
      .useValue(authGuardMock)
      .overrideGuard(RolesGuard)
      .useValue(rolesGuardMock)
      .overrideProvider(HousingAssignmentService)
      .useValue(serviceMock)
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/GET all housing-assignments ', async () => {
    const getEntities: HousingAssignmentDTO[] = (await request(app.getHttpServer()).get('/api/housing-assignments').expect(200)).body;

    expect(getEntities).toEqual(entityMock);
  });

  it('/GET housing-assignments by id', async () => {
    const getEntity: HousingAssignmentDTO = (
      await request(app.getHttpServer()).get(`/api/housing-assignments/${entityMock.id}`).expect(200)
    ).body;

    expect(getEntity).toEqual(entityMock);
  });

  it('/POST create housing-assignments', async () => {
    const createdEntity: HousingAssignmentDTO = (
      await request(app.getHttpServer()).post('/api/housing-assignments').send(entityMock).expect(201)
    ).body;

    expect(createdEntity).toEqual(entityMock);
  });

  it('/PUT update housing-assignments', async () => {
    const updatedEntity: HousingAssignmentDTO = (
      await request(app.getHttpServer()).put('/api/housing-assignments').send(entityMock).expect(201)
    ).body;

    expect(updatedEntity).toEqual(entityMock);
  });

  it('/PUT update housing-assignments from id', async () => {
    const updatedEntity: HousingAssignmentDTO = (
      await request(app.getHttpServer()).put(`/api/housing-assignments/${entityMock.id}`).send(entityMock).expect(201)
    ).body;

    expect(updatedEntity).toEqual(entityMock);
  });

  it('/DELETE housing-assignments', async () => {
    const deletedEntity: HousingAssignmentDTO = (
      await request(app.getHttpServer()).delete(`/api/housing-assignments/${entityMock.id}`).expect(204)
    ).body;

    expect(deletedEntity).toEqual({});
  });

  afterEach(async () => {
    await app?.close();
  });
});
